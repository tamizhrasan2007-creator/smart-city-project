# 🏙️ Smart City Project

> A modern, responsive full-stack civic intelligence and urban information platform built with **HTML5, CSS3, JavaScript (ES6+), Node.js, Express, and SQLite**.

---

## 🌟 Overview

The **Smart City Project** is an interactive, data-driven municipal platform designed for citizens, travelers, and city planners to explore India's leading smart metros. Users can register and log in, search and filter cities, inspect detailed municipal profiles, check real-time weather and 5-day meteorological forecasts, browse city news bulletins, and bookmark favorite cities. 

Municipal administrators gain access to a dedicated **Admin Console** to monitor platform statistics, publish civic news, manage user permissions, and perform full CRUD operations on city dossiers.

---

## 🚀 Key Features

### 👤 Citizen / User Features
- **Authentication & Security**: Secure user registration, login, and JWT-based session management with `bcryptjs` password encryption.
- **City Search & Discovery**: Real-time debounced search, filter by state, and sort options (A–Z, Z–A, Newly Added).
- **Comprehensive City Dossiers**:
  - Name, state, country, description, and key specialization / UNESCO tags.
  - Demographics: Population, geographic area, official languages, and currency.
  - **Attractions & Heritage**: Landmarks, monuments, and cultural destinations.
  - **Transportation Grid**: International airports, railway junctions, metro lines, and highways.
  - **Education & Research**: Premier universities, colleges, and research institutes.
  - **Healthcare Infrastructure**: Leading multi-speciality hospitals and medical centres.
  - **Economy & Industry**: Core industries, manufacturing clusters, and tech corridors.
- **Live Weather Observatory**:
  - Real-time temperature, condition, humidity, wind velocity, air quality (AQI), barometric pressure, visibility, and UV index.
  - 5-Day daily forecast with weather icons and temperature highs/lows.
  - Live **OpenWeatherMap API integration** with an automatic realistic fallback engine.
- **Civic Newsroom**:
  - Categorized news bulletins (Transportation, Smart Mobility, Urban Heritage, Economy, Clean Energy, Life Sciences).
  - Search news by keyword and filter by city.
  - In-depth modal story reader.
  - Optional **NewsAPI integration** with curated fallback articles.
- **Saved Cities Watchlist**:
  - One-click heart toggle on city cards or within dossiers.
  - Persistent per-user favorites stored in the SQLite database.
- **Profile & Settings**:
  - Update full name, bio, and civic interests.
  - Secure password change dialog.
  - Light / Dark mode toggle (persisted via `localStorage`).

### 🛡️ Administrative Console
- **Platform Analytics**: Total cities registered, active citizen accounts, saved favorites, and published news bulletins.
- **Demographic Insights**: Regional city distribution by state and top favorited cities leaderboard.
- **City Management (Full CRUD)**:
  - Add new smart cities with full demographic, transit, educational, and healthcare fields.
  - Edit existing city dossiers with pre-populated form fields.
  - Delete cities with confirmation dialogs.
- **User Management**:
  - View all registered citizens with registration timestamps and favorites counts.
  - Promote citizens to Administrator or demote administrators.
  - Delete user accounts (with protection against self-deletion).
- **News Publishing**:
  - Publish municipal bulletins tied to specific cities or nationwide.
  - Delete outdated news items.

---

## 🏛️ Seeded Sample Cities

The platform comes pre-seeded with rich, authentic data for 7 premier smart cities:

1. **Chennai** *(Tamil Nadu)* – "Detroit of Asia", Healthcare Capital of India, SaaS & Culture Hub.
2. **Madurai** *(Tamil Nadu)* – "Athens of the East", Historic Temple City, Jasmine & Heritage Capital.
3. **Coimbatore** *(Tamil Nadu)* – "Manchester of South India", Pump & Motor Manufacturing Epicenter.
4. **Bengaluru** *(Karnataka)* – "Silicon Valley of India", DeepTech, Aerospace & Startup Capital.
5. **Mumbai** *(Maharashtra)* – "Financial Capital of India", Bollywood, Sea Links & Maritime Port.
6. **Delhi** *(Delhi NCR)* – "National Capital", Political, Diplomatic & Historical Epicenter.
7. **Hyderabad** *(Telangana)* – "City of Pearls", "Cyberabad", Global Vaccine & Life Sciences Capital.

---

## 🛠️ Tech Stack & Architecture

- **Frontend**:
  - Pure HTML5 semantic structure.
  - Modern CSS3 with CSS Custom Properties, Glassmorphism, CSS Grid, and Flexbox.
  - Vanilla JavaScript (ES6+ Modules, Fetch API, DOM manipulation, custom event dispatching).
  - Responsive mobile-first design with drawer navigation.
  - Light & Dark mode support with smooth transitions.
- **Backend**:
  - Node.js (v22+ / v26+) & Express 5.
  - Built-in `node:sqlite` (`DatabaseSync`) for zero-dependency, lightning-fast database persistence.
  - `bcryptjs` for secure password hashing.
  - `jsonwebtoken` (JWT) for stateless bearer authentication.
  - `cors` and `dotenv` for configuration and cross-origin resource sharing.
- **Database Schema**:
  - `users` (id, name, email, password, role, bio, created_at)
  - `cities` (id, name, state, country, description, population, area, language, currency, attractions, transportation, education, healthcare, economy, specializations, image_url, latitude, longitude)
  - `favorites` (id, user_id, city_id, created_at) [Foreign Keys + CASCADE]
  - `news` (id, city_id, title, summary, content, category, source, image_url, published_at)

---

## 📂 Project Directory Structure

```
smart-city-project/
├── .env                  # Environment configuration
├── .env.example          # Sample environment template
├── package.json          # Project manifest and scripts
├── server.js             # Express application server and route registry
├── README.md             # Project documentation
├── db/
│   ├── database.js       # SQLite schema initialization and sample seeding
│   └── smartcity.db      # SQLite database file (created automatically)
├── middleware/
│   └── auth.js           # JWT authentication and Admin role enforcement
├── routes/
│   ├── auth.js           # Register, login, profile, and password update
│   ├── cities.js         # Cities CRUD, live search, and state filtering
│   ├── favorites.js      # Saved cities management and toggle
│   ├── weather.js        # Weather API & dynamic climate simulation engine
│   ├── news.js           # Newsfeed API and news administration
│   └── admin.js          # Admin statistics, user roles, and system controls
└── public/
    ├── index.html        # Single-Page Application interface
    ├── assets/
    │   └── favicon.svg   # Custom smart city vector icon
    ├── css/
    │   ├── styles.css    # Typography, design system tokens, themes, layout
    │   ├── components.css# Cards, modals, buttons, badges, tables, toasts
    │   └── animations.css# Skeletons, shimmers, transitions, keyframes
    └── js/
        ├── api.js        # Central Fetch wrapper with JWT headers and toasts
        ├── theme.js      # Light/Dark mode state management
        ├── auth.js       # Authentication state, login/register modals, profile
        ├── cities.js     # Cities explorer, live search, and full modal dossier
        ├── weather.js    # Weather station widget and 5-day forecast
        ├── news.js       # Newsfeed cards, categories, and story reader
        ├── favorites.js  # User watchlist manager
        ├── admin.js      # Admin console, stats, and CRUD operations
        └── app.js        # SPA hash router and application bootstrapper
```

---

## ⚡ Quick Start Guide

### 1. Prerequisites
- **Node.js** (v22.0.0 or higher recommended, fully compatible with Node v26).
- **npm** (bundled with Node.js).

### 2. Installation
Open a terminal in the project directory:
```bash
cd d:\smart-city-project
npm install
```

### 3. Running the Server
Start the production server:
```bash
npm start
```
Or start in development mode with automatic restart:
```bash
npm run dev
```

### 4. Access the Platform
Open your browser and navigate to:
```
http://localhost:3000
```

---

## 🔑 Default Demo Accounts

For instant testing and evaluation, the following pre-configured accounts are available (and can also be loaded with 1-click in the Sign In modal):

| Role | Email | Password | Access Capabilities |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin@smartcity.gov` | `Admin@1234` | Full access to Admin Console, City CRUD, User management, News publishing |
| **Citizen User** | `citizen@smartcity.gov` | `Citizen@1234` | Explore cities, save favorites, view personal profile & weather |

*You can also register any new account directly via the "Register" button.*

---

## 🌐 External APIs (Optional)

The application is engineered to work **100% out-of-the-box** without any third-party API keys required. It includes a climate simulation engine that calculates realistic temperatures, AQI, and forecasts based on each city's climate profile.

If you wish to connect live external APIs, simply update `.env`:
```env
OPENWEATHER_API_KEY=your_openweathermap_api_key_here
NEWS_API_KEY=your_newsapi_org_key_here
```

---

## 📡 API Reference Summary

### Authentication (`/api/auth`)
- `POST /api/auth/register` – Register a new citizen account
- `POST /api/auth/login` – Authenticate and receive JWT token
- `GET /api/auth/me` – Retrieve profile of authenticated user
- `PUT /api/auth/profile` – Update user name and bio
- `PUT /api/auth/password` – Update user password

### Cities (`/api/cities`)
- `GET /api/cities` – Query and filter cities (`?search=...&state=...&sortBy=...`)
- `GET /api/cities/:id` – Retrieve complete city dossier and related news
- `POST /api/cities` – *Admin only*: Add a new city
- `PUT /api/cities/:id` – *Admin only*: Edit an existing city
- `DELETE /api/cities/:id` – *Admin only*: Remove a city

### Saved Favorites (`/api/favorites`)
- `GET /api/favorites` – Retrieve favorite cities for logged-in user
- `POST /api/favorites/toggle` – Add or remove city from favorites

### Weather & Meteorology (`/api/weather`)
- `GET /api/weather/:cityName` – Current weather conditions, metrics, and 5-day forecast

### Civic News (`/api/news`)
- `GET /api/news` – Retrieve news bulletins (`?cityId=...&category=...&search=...`)
- `GET /api/news/:id` – Get single news article
- `POST /api/news` – *Admin only*: Publish a news bulletin
- `DELETE /api/news/:id` – *Admin only*: Delete a news bulletin

### Administration (`/api/admin`)
- `GET /api/admin/stats` – Platform KPI statistics and regional breakdowns
- `GET /api/admin/users` – List all user accounts
- `PUT /api/admin/users/:id/role` – Change user role (`admin` or `user`)
- `DELETE /api/admin/users/:id` – Delete a user account

---

## 📄 License
This project is licensed under the MIT License.
