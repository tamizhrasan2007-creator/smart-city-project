require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('node:path');

// Ensure database is initialized
const db = require('./db/database');

const authRoutes = require('./routes/auth');
const citiesRoutes = require('./routes/cities');
const favoritesRoutes = require('./routes/favorites');
const weatherRoutes = require('./routes/weather');
const newsRoutes = require('./routes/news');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend assets
app.use(express.static(path.join(__dirname, 'public')));

// Mount API routes
app.use('/api/auth', authRoutes);
app.use('/api/cities', citiesRoutes);
app.use('/api/favorites', favoritesRoutes);
app.use('/api/weather', weatherRoutes);
app.use('/api/news', newsRoutes);
app.use('/api/admin', adminRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    platform: 'Smart City Information Platform'
  });
});

// Single Page Application fallback for any unhandled non-API routes
app.use((req, res, next) => {
  if (req.method === 'GET' && !req.path.startsWith('/api')) {
    return res.sendFile(path.join(__dirname, 'public', 'index.html'));
  }
  next();
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err);
  res.status(500).json({
    success: false,
    message: 'An unexpected internal error occurred on the server.'
  });
});

// Start listening
app.listen(PORT, () => {
  console.log(`======================================================`);
  console.log(`🏙️  Smart City Project - Server Running Successfully!`);
  console.log(`🌐  Local URL:       http://localhost:${PORT}`);
  console.log(`🔑  Default Admin:   admin@smartcity.gov  /  Admin@1234`);
  console.log(`👤  Default Citizen: citizen@smartcity.gov /  Citizen@1234`);
  console.log(`======================================================`);
});
