/**
 * Smart City Project - City News & Public Pressfeed Module
 */

const newsManager = {
  newsList: [],
  activeCategory: 'All',
  activeCityId: '',
  searchKeyword: '',

  init() {
    this.bindEvents();
    this.loadNews();
  },

  bindEvents() {
    // News category chips
    document.querySelectorAll('.news-category-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        document.querySelectorAll('.news-category-chip').forEach(c => c.classList.remove('active'));
        e.currentTarget.classList.add('active');
        this.activeCategory = e.currentTarget.dataset.category || 'All';
        this.loadNews();
      });
    });

    const searchInput = document.getElementById('newsSearchInput');
    if (searchInput) {
      let timer;
      searchInput.addEventListener('input', (e) => {
        clearTimeout(timer);
        timer = setTimeout(() => {
          this.searchKeyword = e.target.value.trim();
          this.loadNews();
        }, 300);
      });
    }

    const citySelect = document.getElementById('newsCitySelect');
    if (citySelect) {
      citySelect.addEventListener('change', (e) => {
        this.activeCityId = e.target.value;
        this.loadNews();
      });
    }
  },

  async loadNews() {
    const grid = document.getElementById('newsGrid');
    if (!grid) return;

    grid.innerHTML = Array(4).fill(0).map(() => `
      <div class="skeleton-card" style="height: 320px;">
        <div class="skeleton skeleton-img" style="height: 140px;"></div>
        <div class="skeleton skeleton-title"></div>
        <div class="skeleton skeleton-text"></div>
      </div>
    `).join('');

    const params = new URLSearchParams();
    if (this.activeCategory && this.activeCategory !== 'All') params.append('category', this.activeCategory);
    if (this.activeCityId) params.append('cityId', this.activeCityId);
    if (this.searchKeyword) params.append('search', this.searchKeyword);

    const res = await api.get(`/news?${params.toString()}`);

    if (res.ok && res.data.success) {
      this.newsList = res.data.news;
      this.renderNews();
    } else {
      grid.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="empty-icon">📰</div>
          <div class="empty-title">Unable to load news</div>
          <p class="empty-desc">${res.data.message || 'Please verify your internet connection.'}</p>
        </div>
      `;
    }
  },

  renderNews() {
    const grid = document.getElementById('newsGrid');
    const emptyState = document.getElementById('newsEmptyState');
    if (!grid) return;

    if (this.newsList.length === 0) {
      grid.innerHTML = '';
      if (emptyState) emptyState.style.display = 'flex';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';

    grid.innerHTML = this.newsList.map(item => `
      <div class="news-card animate-fade-in">
        <div class="news-card-img-wrap">
          <img src="${item.image_url || 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80'}" 
               alt="${item.title}" class="news-card-img" loading="lazy" />
        </div>

        <div class="news-card-body">
          <div class="news-meta-row">
            <span class="badge badge-accent">${item.category}</span>
            <span>${this.formatTime(item.published_at)}</span>
          </div>

          <h3 class="news-card-title">${item.title}</h3>
          <p class="news-card-summary">${item.summary}</p>
        </div>

        <div class="news-card-footer">
          <div style="font-size: 0.8rem; color: var(--text-muted); font-weight: 600;">
            ${item.city_name ? `📍 ${item.city_name}` : '🌐 National Urban Wire'}
          </div>
          <button class="btn btn-outline btn-sm" onclick="newsManager.openArticleModal('${item.id}')">
            Read Full Story &rarr;
          </button>
        </div>
      </div>
    `).join('');
  },

  formatTime(dateStr) {
    if (!dateStr) return 'Recently';
    const date = new Date(dateStr);
    const diffHours = Math.floor((Date.now() - date.getTime()) / (1000 * 3600));

    if (diffHours < 1) return 'Just now';
    if (diffHours < 24) return `${diffHours} hours ago`;
    const diffDays = Math.floor(diffHours / 24);
    if (diffDays < 7) return `${diffDays} days ago`;
    return date.toLocaleDateString();
  },

  openArticleModal(articleId) {
    const item = this.newsList.find(n => String(n.id) === String(articleId));
    if (!item) return;

    const modal = document.getElementById('articleDetailModal');
    if (!modal) return;

    document.getElementById('articleModalTitle').textContent = item.title;
    document.getElementById('articleModalCategory').textContent = item.category;
    document.getElementById('articleModalSource').textContent = `Source: ${item.source} • Published ${new Date(item.published_at).toLocaleString()}`;
    document.getElementById('articleModalImage').src = item.image_url;
    document.getElementById('articleModalContent').innerHTML = `
      <p style="font-size: 1.1rem; font-weight: 600; color: var(--text-primary); line-height: 1.6; margin-bottom: 1rem;">
        ${item.summary}
      </p>
      <div style="font-size: 1rem; color: var(--text-secondary); line-height: 1.8; white-space: pre-line;">
        ${item.content}
      </div>
    `;

    modal.classList.add('open');
  }
};

window.newsManager = newsManager;
document.addEventListener('DOMContentLoaded', () => newsManager.init());
