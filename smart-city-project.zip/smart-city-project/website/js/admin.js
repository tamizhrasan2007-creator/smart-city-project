/**
 * Smart City Project - Admin Dashboard & Management System
 */

const adminManager = {
  activeTab: 'stats',
  stats: null,
  users: [],
  cities: [],
  news: [],

  init() {
    this.bindEvents();

    window.addEventListener('authChange', (e) => {
      const user = e.detail?.user;
      if (user && user.role === 'admin') {
        this.loadAdminData();
      }
    });

    if (api.getUser()?.role === 'admin') {
      this.loadAdminData();
    }
  },

  bindEvents() {
    // Admin Subtabs
    document.querySelectorAll('.admin-tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.admin-tab-btn').forEach(b => b.classList.remove('active'));
        e.currentTarget.classList.add('active');
        this.switchTab(e.currentTarget.dataset.tab);
      });
    });

    // Add City Form
    const cityForm = document.getElementById('adminCityForm');
    if (cityForm) {
      cityForm.addEventListener('submit', (e) => this.handleSaveCity(e));
    }

    // Open Add City Modal
    const openAddCityBtn = document.getElementById('openAddCityModalBtn');
    if (openAddCityBtn) {
      openAddCityBtn.addEventListener('click', () => this.showCityModal());
    }

    // Add News Form
    const newsForm = document.getElementById('adminNewsForm');
    if (newsForm) {
      newsForm.addEventListener('submit', (e) => this.handlePublishNews(e));
    }

    // Open Add News Modal
    const openAddNewsBtn = document.getElementById('openAddNewsModalBtn');
    if (openAddNewsBtn) {
      openAddNewsBtn.addEventListener('click', () => this.showNewsModal());
    }
  },

  switchTab(tab) {
    this.activeTab = tab;
    document.querySelectorAll('.admin-tab-content').forEach(section => {
      section.style.display = section.id === `adminTab_${tab}` ? 'block' : 'none';
    });

    if (tab === 'stats') this.loadStats();
    if (tab === 'cities') this.loadAdminCities();
    if (tab === 'users') this.loadAdminUsers();
    if (tab === 'news') this.loadAdminNews();
  },

  async loadAdminData() {
    this.loadStats();
    this.loadAdminCities();
    this.loadAdminUsers();
    this.loadAdminNews();
  },

  async loadStats() {
    const res = await api.get('/admin/stats');
    if (res.ok && res.data.success) {
      this.stats = res.data.stats;
      this.renderStats();
    }
  },

  renderStats() {
    if (!this.stats) return;

    document.getElementById('statTotalCities').textContent = this.stats.totalCities;
    document.getElementById('statTotalUsers').textContent = this.stats.totalUsers;
    document.getElementById('statTotalFavorites').textContent = this.stats.totalFavorites;
    document.getElementById('statTotalNews').textContent = this.stats.totalNews;

    // Render State breakdown list
    const stateListEl = document.getElementById('adminStatsStatesList');
    if (stateListEl) {
      stateListEl.innerHTML = this.stats.citiesByState.map(s => `
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.65rem 0; border-bottom: 1px solid var(--border-color);">
          <span style="font-weight: 600; color: var(--text-primary);">${s.state}</span>
          <span class="badge badge-primary">${s.count} Cities</span>
        </div>
      `).join('');
    }

    // Render Top Favorited Cities
    const topFavEl = document.getElementById('adminTopFavList');
    if (topFavEl) {
      topFavEl.innerHTML = this.stats.topFavorited.map(c => `
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.65rem 0; border-bottom: 1px solid var(--border-color);">
          <span style="font-weight: 600; color: var(--text-primary);">${c.name} (${c.state})</span>
          <span class="badge badge-accent">❤️ ${c.favorite_count} Saves</span>
        </div>
      `).join('');
    }
  },

  /* ================= Manage Cities ================= */
  async loadAdminCities() {
    const res = await api.get('/cities');
    if (res.ok && res.data.success) {
      this.cities = res.data.cities;
      this.renderCitiesTable();
    }
  },

  renderCitiesTable() {
    const tbody = document.getElementById('adminCitiesTableBody');
    if (!tbody) return;

    tbody.innerHTML = this.cities.map(city => `
      <tr>
        <td><strong>#${city.id}</strong></td>
        <td>
          <div style="display: flex; align-items: center; gap: 0.75rem;">
            <img src="${city.image_url}" alt="${city.name}" style="width: 44px; height: 32px; object-fit: cover; border-radius: 4px;" />
            <strong style="color: var(--text-primary); font-size: 0.95rem;">${city.name}</strong>
          </div>
        </td>
        <td>${city.state}</td>
        <td>${city.population}</td>
        <td><span class="badge badge-accent">${city.specializations ? city.specializations.split(',')[0] : 'Smart City'}</span></td>
        <td>
          <div style="display: flex; gap: 0.5rem;">
            <button class="btn btn-secondary btn-sm" onclick="adminManager.showCityModal(${city.id})">Edit</button>
            <button class="btn btn-danger btn-sm" onclick="adminManager.deleteCity(${city.id}, '${city.name}')">Delete</button>
          </div>
        </td>
      </tr>
    `).join('');
  },

  showCityModal(cityId = null) {
    const modal = document.getElementById('adminCityModal');
    const form = document.getElementById('adminCityForm');
    const title = document.getElementById('adminCityModalTitle');

    if (!modal || !form) return;

    form.reset();
    document.getElementById('adminCityId').value = '';

    if (cityId) {
      const city = this.cities.find(c => c.id === cityId);
      if (city) {
        title.textContent = `Edit City: ${city.name}`;
        document.getElementById('adminCityId').value = city.id;
        document.getElementById('cityNameInput').value = city.name || '';
        document.getElementById('cityStateInput').value = city.state || '';
        document.getElementById('cityCountryInput').value = city.country || 'India';
        document.getElementById('cityPopulationInput').value = city.population || '';
        document.getElementById('cityAreaInput').value = city.area || '';
        document.getElementById('cityLanguageInput').value = city.language || '';
        document.getElementById('cityCurrencyInput').value = city.currency || 'INR (₹)';
        document.getElementById('citySpecializationsInput').value = city.specializations || '';
        document.getElementById('cityImageUrlInput').value = city.image_url || '';
        document.getElementById('cityDescriptionInput').value = city.description || '';
        
        // Attractions (array to newline)
        const attractions = Array.isArray(city.attractions) ? city.attractions.join('\n') : city.attractions;
        document.getElementById('cityAttractionsInput').value = attractions || '';

        // Transportation (object or string)
        const trans = typeof city.transportation === 'object' ? JSON.stringify(city.transportation, null, 2) : city.transportation;
        document.getElementById('cityTransportationInput').value = trans || '';

        // Education (array to newline)
        const edu = Array.isArray(city.education) ? city.education.join('\n') : city.education;
        document.getElementById('cityEducationInput').value = edu || '';

        // Healthcare (array to newline)
        const health = Array.isArray(city.healthcare) ? city.healthcare.join('\n') : city.healthcare;
        document.getElementById('cityHealthcareInput').value = health || '';

        document.getElementById('cityEconomyInput').value = city.economy || '';
      }
    } else {
      title.textContent = 'Add New Smart City';
      document.getElementById('cityCountryInput').value = 'India';
      document.getElementById('cityCurrencyInput').value = 'INR (₹)';
    }

    modal.classList.add('open');
  },

  async handleSaveCity(e) {
    e.preventDefault();
    const cityId = document.getElementById('adminCityId').value;
    const name = document.getElementById('cityNameInput').value.trim();
    const state = document.getElementById('cityStateInput').value.trim();
    const country = document.getElementById('cityCountryInput').value.trim();
    const population = document.getElementById('cityPopulationInput').value.trim();
    const area = document.getElementById('cityAreaInput').value.trim();
    const language = document.getElementById('cityLanguageInput').value.trim();
    const currency = document.getElementById('cityCurrencyInput').value.trim();
    const specializations = document.getElementById('citySpecializationsInput').value.trim();
    const image_url = document.getElementById('cityImageUrlInput').value.trim();
    const description = document.getElementById('cityDescriptionInput').value.trim();
    const attractionsRaw = document.getElementById('cityAttractionsInput').value.trim();
    const transRaw = document.getElementById('cityTransportationInput').value.trim();
    const eduRaw = document.getElementById('cityEducationInput').value.trim();
    const healthRaw = document.getElementById('cityHealthcareInput').value.trim();
    const economy = document.getElementById('cityEconomyInput').value.trim();

    if (!name || !state || !population || !description) {
      showToast('Validation Error', 'Name, State, Population and Description are required.', 'warning');
      return;
    }

    // Split newline fields into arrays
    const attractions = attractionsRaw.split('\n').map(s => s.trim()).filter(Boolean);
    const education = eduRaw.split('\n').map(s => s.trim()).filter(Boolean);
    const healthcare = healthRaw.split('\n').map(s => s.trim()).filter(Boolean);

    let transportation = {};
    try {
      transportation = JSON.parse(transRaw);
    } catch {
      transportation = { general: transRaw };
    }

    const payload = {
      name, state, country, population, area, language, currency,
      specializations, image_url, description, attractions,
      transportation, education, healthcare, economy
    };

    let res;
    if (cityId) {
      res = await api.put(`/cities/${cityId}`, payload);
    } else {
      res = await api.post('/cities', payload);
    }

    if (res.ok && res.data.success) {
      showToast('Success', res.data.message, 'success');
      document.getElementById('adminCityModal').classList.remove('open');
      this.loadAdminCities();
      this.loadStats();
      if (window.citiesManager) window.citiesManager.loadCities();
    } else {
      showToast('Save Failed', res.data.message || 'Could not save city.', 'error');
    }
  },

  async deleteCity(cityId, cityName) {
    if (!confirm(`Are you sure you want to delete ${cityName} from Smart City records? This action cannot be undone.`)) {
      return;
    }

    const res = await api.delete(`/cities/${cityId}`);
    if (res.ok && res.data.success) {
      showToast('Deleted', res.data.message, 'info');
      this.loadAdminCities();
      this.loadStats();
      if (window.citiesManager) window.citiesManager.loadCities();
    } else {
      showToast('Delete Failed', res.data.message || 'Could not delete city.', 'error');
    }
  },

  /* ================= Manage Users ================= */
  async loadAdminUsers() {
    const res = await api.get('/admin/users');
    if (res.ok && res.data.success) {
      this.users = res.data.users;
      this.renderUsersTable();
    }
  },

  renderUsersTable() {
    const tbody = document.getElementById('adminUsersTableBody');
    if (!tbody) return;

    const currentUserId = api.getUser()?.id;

    tbody.innerHTML = this.users.map(u => `
      <tr>
        <td><strong>#${u.id}</strong></td>
        <td>
          <strong style="color: var(--text-primary); font-size: 0.95rem;">${u.name}</strong>
          ${u.id === currentUserId ? ' <span class="badge badge-accent">You</span>' : ''}
        </td>
        <td>${u.email}</td>
        <td>
          <span class="badge ${u.role === 'admin' ? 'badge-primary' : 'badge-success'}">
            ${u.role.toUpperCase()}
          </span>
        </td>
        <td>❤️ ${u.favorites_count}</td>
        <td>${new Date(u.created_at).toLocaleDateString()}</td>
        <td>
          <div style="display: flex; gap: 0.5rem;">
            ${u.id !== currentUserId ? `
              <button class="btn btn-secondary btn-sm" onclick="adminManager.toggleUserRole(${u.id}, '${u.role === 'admin' ? 'user' : 'admin'}')">
                ${u.role === 'admin' ? 'Demote to Citizen' : 'Promote to Admin'}
              </button>
              <button class="btn btn-danger btn-sm" onclick="adminManager.deleteUser(${u.id}, '${u.name}')">
                Delete
              </button>
            ` : '<span style="color: var(--text-muted); font-size: 0.85rem;">Active Admin</span>'}
          </div>
        </td>
      </tr>
    `).join('');
  },

  async toggleUserRole(userId, newRole) {
    const res = await api.put(`/admin/users/${userId}/role`, { role: newRole });
    if (res.ok && res.data.success) {
      showToast('Role Updated', res.data.message, 'success');
      this.loadAdminUsers();
    } else {
      showToast('Error', res.data.message || 'Could not change role.', 'error');
    }
  },

  async deleteUser(userId, userName) {
    if (!confirm(`Are you sure you want to delete account for "${userName}"?`)) {
      return;
    }

    const res = await api.delete(`/admin/users/${userId}`);
    if (res.ok && res.data.success) {
      showToast('Deleted', res.data.message, 'info');
      this.loadAdminUsers();
      this.loadStats();
    } else {
      showToast('Error', res.data.message || 'Could not delete user.', 'error');
    }
  },

  /* ================= Manage News ================= */
  async loadAdminNews() {
    const res = await api.get('/news');
    if (res.ok && res.data.success) {
      this.news = res.data.news;
      this.renderNewsTable();
    }
  },

  renderNewsTable() {
    const tbody = document.getElementById('adminNewsTableBody');
    if (!tbody) return;

    tbody.innerHTML = this.news.map(n => `
      <tr>
        <td><strong>#${n.id}</strong></td>
        <td>
          <div style="font-weight: 700; color: var(--text-primary); max-width: 320px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
            ${n.title}
          </div>
        </td>
        <td><span class="badge badge-accent">${n.category}</span></td>
        <td>${n.city_name || 'National'}</td>
        <td>${new Date(n.published_at).toLocaleDateString()}</td>
        <td>
          <button class="btn btn-danger btn-sm" onclick="adminManager.deleteNews('${n.id}', '${n.title.replace(/'/g, "\\'")}')">
            Delete
          </button>
        </td>
      </tr>
    `).join('');
  },

  showNewsModal() {
    const modal = document.getElementById('adminNewsModal');
    const form = document.getElementById('adminNewsForm');
    const citySelect = document.getElementById('adminNewsCitySelect');

    if (!modal || !form) return;
    form.reset();

    // Populate cities in news form
    if (citySelect) {
      citySelect.innerHTML = '<option value="">National / Pan-City</option>' +
        this.cities.map(c => `<option value="${c.id}">${c.name} (${c.state})</option>`).join('');
    }

    modal.classList.add('open');
  },

  async handlePublishNews(e) {
    e.preventDefault();
    const city_id = document.getElementById('adminNewsCitySelect').value;
    const title = document.getElementById('newsTitleInput').value.trim();
    const category = document.getElementById('newsCategoryInput').value;
    const source = document.getElementById('newsSourceInput').value.trim();
    const image_url = document.getElementById('newsImageUrlInput').value.trim();
    const summary = document.getElementById('newsSummaryInput').value.trim();
    const content = document.getElementById('newsContentInput').value.trim();

    if (!title || !summary || !content) {
      showToast('Validation Error', 'Title, summary, and article content are required.', 'warning');
      return;
    }

    const res = await api.post('/news', {
      city_id: city_id || null,
      title,
      category,
      source: source || 'Smart City Pressfeed',
      image_url: image_url || 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80',
      summary,
      content
    });

    if (res.ok && res.data.success) {
      showToast('Published', 'News article has been published successfully!', 'success');
      document.getElementById('adminNewsModal').classList.remove('open');
      this.loadAdminNews();
      this.loadStats();
      if (window.newsManager) window.newsManager.loadNews();
    } else {
      showToast('Publish Failed', res.data.message || 'Could not publish article.', 'error');
    }
  },

  async deleteNews(newsId, newsTitle) {
    if (!confirm(`Are you sure you want to delete "${newsTitle}"?`)) {
      return;
    }

    const res = await api.delete(`/news/${newsId}`);
    if (res.ok && res.data.success) {
      showToast('Deleted', res.data.message, 'info');
      this.loadAdminNews();
      this.loadStats();
      if (window.newsManager) window.newsManager.loadNews();
    } else {
      showToast('Delete Failed', res.data.message || 'Could not delete article.', 'error');
    }
  }
};

window.adminManager = adminManager;
document.addEventListener('DOMContentLoaded', () => adminManager.init());
