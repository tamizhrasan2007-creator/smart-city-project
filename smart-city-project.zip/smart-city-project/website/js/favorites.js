/**
 * Smart City Project - User Favorites Management
 */

const favoritesManager = {
  favorites: [],

  init() {
    this.loadFavorites();

    window.addEventListener('authChange', () => {
      this.loadFavorites();
    });

    window.addEventListener('favoriteChanged', () => {
      this.loadFavorites();
    });
  },

  async loadFavorites() {
    const container = document.getElementById('favoritesGrid');
    const guestState = document.getElementById('favoritesGuestState');
    const emptyState = document.getElementById('favoritesEmptyState');

    if (!container) return;

    if (!api.getToken()) {
      container.innerHTML = '';
      if (guestState) guestState.style.display = 'flex';
      if (emptyState) emptyState.style.display = 'none';
      return;
    }

    if (guestState) guestState.style.display = 'none';

    // Skeleton loaders
    container.innerHTML = Array(3).fill(0).map(() => `
      <div class="skeleton-card">
        <div class="skeleton skeleton-img"></div>
        <div class="skeleton skeleton-title"></div>
        <div class="skeleton skeleton-text"></div>
      </div>
    `).join('');

    const res = await api.get('/favorites');

    if (res.ok && res.data.success) {
      this.favorites = res.data.favorites;
      this.renderFavorites();

      // Update badge in navigation
      const navFavBadge = document.getElementById('navFavoritesCountBadge');
      if (navFavBadge) {
        navFavBadge.textContent = this.favorites.length;
        navFavBadge.style.display = this.favorites.length > 0 ? 'inline-block' : 'none';
      }
    } else {
      container.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="empty-icon">⚠️</div>
          <div class="empty-title">Failed to load saved cities</div>
          <p class="empty-desc">${res.data.message || 'Please try again later.'}</p>
        </div>
      `;
    }
  },

  renderFavorites() {
    const container = document.getElementById('favoritesGrid');
    const emptyState = document.getElementById('favoritesEmptyState');
    if (!container) return;

    if (this.favorites.length === 0) {
      container.innerHTML = '';
      if (emptyState) emptyState.style.display = 'flex';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';

    container.innerHTML = this.favorites.map(city => `
      <div class="city-card animate-fade-in" id="fav_card_${city.id}">
        <div class="city-card-img-wrap">
          <img src="${city.image_url}" alt="${city.name}" class="city-card-img" loading="lazy" />
          <div class="city-card-gradient"></div>

          <div class="city-card-badges">
            <span class="badge badge-accent">${city.state}</span>
            <button class="fav-btn active" 
                    onclick="favoritesManager.removeFavorite(${city.id}, event)"
                    title="Remove from favorites"
                    aria-label="Remove from favorites">
              ❤️
            </button>
          </div>

          <div class="city-card-overlay-info">
            <h3 class="city-card-name">${city.name}</h3>
            <div class="city-card-location">📍 ${city.state}, ${city.country}</div>
          </div>
        </div>

        <div class="city-card-body">
          <div class="city-card-specialization">
            <span>✨</span> ${city.specializations ? city.specializations.split(',')[0] : 'Smart City'}
          </div>

          <p class="city-card-desc">${city.description}</p>

          <div class="city-card-meta-chips">
            <div class="meta-chip-item">
              <span class="meta-chip-lbl">Population</span>
              <span class="meta-chip-val">${city.population}</span>
            </div>
            <div class="meta-chip-item">
              <span class="meta-chip-lbl">Area</span>
              <span class="meta-chip-val">${city.area}</span>
            </div>
          </div>
        </div>

        <div class="city-card-footer">
          <span style="font-size: 0.8rem; color: var(--text-muted);">
            Saved on ${city.favorited_at ? new Date(city.favorited_at).toLocaleDateString() : 'Recent'}
          </span>
          <button class="btn btn-outline btn-sm" onclick="citiesManager.viewCityDetails(${city.id})">
            View Dossier &rarr;
          </button>
        </div>
      </div>
    `).join('');
  },

  async removeFavorite(cityId, event) {
    if (event) event.stopPropagation();

    const res = await api.post('/favorites/toggle', { cityId });
    if (res.ok && res.data.success) {
      showToast('Removed', res.data.message, 'info');
      this.favorites = this.favorites.filter(c => c.id !== cityId);
      this.renderFavorites();

      // Dispatch event to sync cities explorer
      window.dispatchEvent(new CustomEvent('favoriteChanged', { detail: { cityId, isFavorite: false } }));
    }
  }
};

window.favoritesManager = favoritesManager;
document.addEventListener('DOMContentLoaded', () => favoritesManager.init());
