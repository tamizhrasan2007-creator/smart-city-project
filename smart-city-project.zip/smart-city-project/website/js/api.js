/**
 * Smart City Project - Central API Client & Toast System
 */

const API_BASE = '/api';

const api = {
  getToken() {
    return localStorage.getItem('smartcity_token');
  },

  setToken(token) {
    if (token) {
      localStorage.setItem('smartcity_token', token);
    } else {
      localStorage.removeItem('smartcity_token');
    }
  },

  getUser() {
    try {
      const u = localStorage.getItem('smartcity_user');
      return u ? JSON.parse(u) : null;
    } catch {
      return null;
    }
  },

  setUser(user) {
    if (user) {
      localStorage.setItem('smartcity_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('smartcity_user');
    }
  },

  clearAuth() {
    localStorage.removeItem('smartcity_token');
    localStorage.removeItem('smartcity_user');
  },

  async request(endpoint, options = {}) {
    const url = `${API_BASE}${endpoint}`;
    const token = this.getToken();

    const headers = {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers
      });

      const data = await response.json().catch(() => ({
        success: false,
        message: 'Invalid response from server.'
      }));

      if (response.status === 401 && token) {
        // Token expired or invalidated
        this.clearAuth();
        showToast('Session Expired', 'Please log in again to continue.', 'warning');
        if (window.auth) window.auth.updateAuthUI();
      }

      return { ok: response.ok, status: response.status, data };
    } catch (error) {
      console.error(`API request error on ${endpoint}:`, error);
      return {
        ok: false,
        status: 0,
        data: {
          success: false,
          message: 'Unable to reach the server. Please check your network connection.'
        }
      };
    }
  },

  get(endpoint) {
    return this.request(endpoint, { method: 'GET' });
  },

  post(endpoint, body) {
    return this.request(endpoint, {
      method: 'POST',
      body: JSON.stringify(body)
    });
  },

  put(endpoint, body) {
    return this.request(endpoint, {
      method: 'PUT',
      body: JSON.stringify(body)
    });
  },

  delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' });
  }
};

/**
 * Global Toast Notification Helper
 */
function showToast(title, message, type = 'info') {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const icons = {
    success: '✅',
    error: '❌',
    warning: '⚠️',
    info: 'ℹ️'
  };

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <span class="toast-icon">${icons[type] || 'ℹ️'}</span>
    <div class="toast-content">
      <div class="toast-title">${title}</div>
      <div class="toast-msg">${message}</div>
    </div>
    <button class="toast-close" aria-label="Close">&times;</button>
  `;

  container.appendChild(toast);

  // Trigger animation
  requestAnimationFrame(() => {
    toast.classList.add('show');
  });

  const closeToast = () => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  };

  toast.querySelector('.toast-close').addEventListener('click', closeToast);

  // Auto dismiss after 4 seconds
  setTimeout(closeToast, 4000);
}

window.api = api;
window.showToast = showToast;
