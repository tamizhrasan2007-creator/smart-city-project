/**
 * Smart City Project - Cities Explorer & Detailed Dossier Modal
 */

const citiesManager = {
  cities: [],
  states: [],
  activeSearch: '',
  activeState: 'all',
  activeSort: 'name_asc',
  searchDebounceTimer: null,

  init() {
    this.bindEvents();
    this.loadCities();

    // Listen for auth change to reload favorite flags
    window.addEventListener('authChange', () => {
      this.loadCities();
    });
  },

  bindEvents() {
    const searchInput = document.getElementById('citySearchInput');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        clearTimeout(this.searchDebounceTimer);
        this.searchDebounceTimer = setTimeout(() => {
          this.activeSearch = e.target.value.trim();
          this.loadCities();
        }, 300);
      });
    }

    // Hero search
    const heroSearchInput = document.getElementById('heroSearchInput');
    const heroSearchBtn = document.getElementById('heroSearchBtn');
    if (heroSearchBtn && heroSearchInput) {
      const executeHeroSearch = () => {
        const val = heroSearchInput.value.trim();
        this.activeSearch = val;
        if (searchInput) searchInput.value = val;
        // Scroll to cities section
        const citiesSection = document.getElementById('citiesSection');
        if (citiesSection) {
          citiesSection.scrollIntoView({ behavior: 'smooth' });
        }
        this.loadCities();
      };

      heroSearchBtn.addEventListener('click', executeHeroSearch);
      heroSearchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') executeHeroSearch();
      });
    }

    // Hero quick tag chips
    document.querySelectorAll('.hero-tag-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const cityName = chip.dataset.city;
        this.activeSearch = cityName;
        if (searchInput) searchInput.value = cityName;
        const citiesSection = document.getElementById('citiesSection');
        if (citiesSection) {
          citiesSection.scrollIntoView({ behavior: 'smooth' });
        }
        this.loadCities();
      });
    });

    const stateSelect = document.getElementById('stateFilterSelect');
    if (stateSelect) {
      stateSelect.addEventListener('change', (e) => {
        this.activeState = e.target.value;
        this.loadCities();
      });
    }

    const sortSelect = document.getElementById('sortBySelect');
    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        this.activeSort = e.target.value;
        this.loadCities();
      });
    }

    // Clear filters button
    const clearBtn = document.getElementById('clearFiltersBtn');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        this.activeSearch = '';
        this.activeState = 'all';
        this.activeSort = 'name_asc';
        if (searchInput) searchInput.value = '';
        if (stateSelect) stateSelect.value = 'all';
        if (sortSelect) sortSelect.value = 'name_asc';
        this.loadCities();
      });
    }
  },

  async loadCities() {
    const grid = document.getElementById('citiesGrid');
    if (!grid) return;

    // Show skeleton loaders
    grid.innerHTML = Array(6).fill(0).map(() => `
      <div class="skeleton-card">
        <div class="skeleton skeleton-img"></div>
        <div class="skeleton skeleton-title"></div>
        <div class="skeleton skeleton-text"></div>
        <div class="skeleton skeleton-text short"></div>
      </div>
    `).join('');

    const params = new URLSearchParams();
    if (this.activeSearch) params.append('search', this.activeSearch);
    if (this.activeState && this.activeState !== 'all') params.append('state', this.activeState);
    if (this.activeSort) params.append('sortBy', this.activeSort);

    const res = await api.get(`/cities?${params.toString()}`);

    if (res.ok && res.data.success) {
      this.cities = res.data.cities;
      this.states = res.data.states || [];
      this.populateStateDropdown();
      this.renderCities();

      // Update counters in Hero stats
      const totalCitiesEl = document.getElementById('heroStatCities');
      if (totalCitiesEl) totalCitiesEl.textContent = this.cities.length;
    } else {
      grid.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="empty-icon">⚠️</div>
          <div class="empty-title">Failed to load cities</div>
          <div class="empty-desc">${res.data.message || 'Please check your connection and try again.'}</div>
          <button class="btn btn-primary" onclick="citiesManager.loadCities()">Retry</button>
        </div>
      `;
    }
  },

  populateStateDropdown() {
    const select = document.getElementById('stateFilterSelect');
    if (!select || select.options.length > 1) return;

    this.states.forEach(state => {
      const opt = document.createElement('option');
      opt.value = state;
      opt.textContent = state;
      select.appendChild(opt);
    });
  },

  renderCities() {
    const grid = document.getElementById('citiesGrid');
    const emptyState = document.getElementById('citiesEmptyState');
    const countBadge = document.getElementById('citiesCountBadge');

    if (countBadge) {
      countBadge.textContent = `${this.cities.length} Cities Found`;
    }

    if (this.cities.length === 0) {
      grid.innerHTML = '';
      if (emptyState) emptyState.style.display = 'flex';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';

    grid.innerHTML = this.cities.map(city => `
      <div class="city-card animate-fade-in" data-city-id="${city.id}">
        <div class="city-card-img-wrap">
          <img src="${city.image_url}" alt="${city.name}" class="city-card-img" loading="lazy" />
          <div class="city-card-gradient"></div>
          
          <div class="city-card-badges">
            <span class="badge badge-accent">${city.state}</span>
            <button class="fav-btn ${city.isFavorite ? 'active' : ''}" 
                    onclick="citiesManager.toggleFavorite(${city.id}, event)"
                    title="${city.isFavorite ? 'Remove from favorites' : 'Add to favorites'}"
                    aria-label="Toggle Favorite">
              ${city.isFavorite ? '❤️' : '🤍'}
            </button>
          </div>

          <div class="city-card-overlay-info">
            <h3 class="city-card-name">${city.name}</h3>
            <div class="city-card-location">📍 ${city.state}, ${city.country}</div>
          </div>
        </div>

        <div class="city-card-body">
          <div class="city-card-specialization">
            <span>✨</span> ${city.specializations.split(',')[0]}
          </div>

          <p class="city-card-desc">${city.description}</p>

          <div class="city-card-meta-chips">
            <div class="meta-chip-item">
              <span class="meta-chip-lbl">Population</span>
              <span class="meta-chip-val">${city.population}</span>
            </div>
            <div class="meta-chip-item">
              <span class="meta-chip-lbl">Area</span>
              <span class="meta-chip-val">${city.area}</span>
            </div>
          </div>
        </div>

        <div class="city-card-footer">
          <div class="mini-weather-pill" id="miniWeather_${city.id}">
            <span>⛅</span> Monitored
          </div>
          <button class="btn btn-outline btn-sm" onclick="citiesManager.viewCityDetails(${city.id})">
            Explore City &rarr;
          </button>
        </div>
      </div>
    `).join('');

    // Fetch mini-weather for visible cities in background
    this.cities.forEach(c => this.loadMiniWeather(c.id, c.name));
  },

  async loadMiniWeather(cityId, cityName) {
    try {
      const res = await api.get(`/weather/${encodeURIComponent(cityName)}`);
      if (res.ok && res.data.success && res.data.weather) {
        const w = res.data.weather;
        const el = document.getElementById(`miniWeather_${cityId}`);
        if (el) {
          el.innerHTML = `<span>🌡️</span> <strong>${w.temperature}°C</strong> &bull; ${w.condition}`;
        }
      }
    } catch {
      // quiet fallback
    }
  },

  async toggleFavorite(cityId, event) {
    if (event) {
      event.stopPropagation();
      event.preventDefault();
    }

    if (!api.getToken()) {
      showToast('Authentication Required', 'Please log in to save your favorite cities.', 'info');
      if (window.auth) window.auth.showAuthModal('login');
      return;
    }

    const btn = event ? event.currentTarget : null;
    if (btn) btn.classList.add('heart-pop');

    const res = await api.post('/favorites/toggle', { cityId });
    if (res.ok && res.data.success) {
      showToast('Favorites Updated', res.data.message, 'success');

      // Update card state in local list
      const city = this.cities.find(c => c.id === cityId);
      if (city) city.isFavorite = res.data.isFavorite;

      // Update icon in DOM
      if (btn) {
        btn.innerHTML = res.data.isFavorite ? '❤️' : '🤍';
        btn.classList.toggle('active', res.data.isFavorite);
      }

      // Also update inside open modal if active
      const modalFavBtn = document.getElementById('modalFavBtn');
      if (modalFavBtn && modalFavBtn.dataset.cityId == cityId) {
        modalFavBtn.innerHTML = res.data.isFavorite ? '❤️ Favorited' : '🤍 Add to Favorites';
        modalFavBtn.classList.toggle('active', res.data.isFavorite);
      }

      // Dispatch event for Favorites tab to refresh
      window.dispatchEvent(new CustomEvent('favoriteChanged', { detail: { cityId, isFavorite: res.data.isFavorite } }));
    } else {
      showToast('Error', res.data.message || 'Could not update favorite.', 'error');
    }
  },

  async viewCityDetails(cityId) {
    const modal = document.getElementById('cityDetailModal');
    if (!modal) return;

    modal.classList.add('open');
    const container = document.getElementById('cityDetailModalContent');
    container.innerHTML = `
      <div class="loading-overlay">
        <span class="spinner spinner-lg"></span>
        <p>Retrieving smart city data, infrastructure profiles, and live meteorology...</p>
      </div>
    `;

    const res = await api.get(`/cities/${cityId}`);
    if (!res.ok || !res.data.success) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">❌</div>
          <div class="empty-title">Failed to load city details</div>
          <p class="empty-desc">${res.data.message || 'Please try again later.'}</p>
        </div>
      `;
      return;
    }

    const city = res.data.city;
    const relatedNews = res.data.relatedNews || [];

    // Format Transportation cleanly
    let transHtml = '';
    if (typeof city.transportation === 'object' && city.transportation !== null) {
      transHtml = Object.entries(city.transportation).map(([mode, desc]) => `
        <li style="margin-bottom: 0.65rem;">
          <strong style="text-transform: capitalize; color: var(--primary);">✈️/🚆 ${mode}:</strong> 
          <span style="color: var(--text-secondary);">${desc}</span>
        </li>
      `).join('');
    } else {
      transHtml = `<li>${city.transportation}</li>`;
    }

    // Format Education
    const eduHtml = Array.isArray(city.education)
      ? city.education.map(e => `
          <div style="background: var(--bg-tertiary); padding: 0.6rem 0.9rem; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle); font-size: 0.9rem; font-weight: 600;">
            🎓 ${e}
          </div>
        `).join('')
      : `<p>${city.education}</p>`;

    // Format Healthcare
    const healthHtml = Array.isArray(city.healthcare)
      ? city.healthcare.map(h => `
          <div style="background: var(--bg-tertiary); padding: 0.6rem 0.9rem; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle); font-size: 0.9rem; font-weight: 600;">
            🏥 ${h}
          </div>
        `).join('')
      : `<p>${city.healthcare}</p>`;

    // Format Attractions
    const attractionsHtml = Array.isArray(city.attractions)
      ? city.attractions.map(a => `
          <div style="background: rgba(37, 99, 235, 0.08); color: var(--primary); padding: 0.5rem 0.85rem; border-radius: var(--radius-full); font-size: 0.85rem; font-weight: 700; border: 1px solid rgba(37, 99, 235, 0.2);">
            🏛️ ${a}
          </div>
        `).join('')
      : `<p>${city.attractions}</p>`;

    container.innerHTML = `
      <!-- Hero Banner inside Modal -->
      <div style="position: relative; height: 260px; border-radius: var(--radius-lg); overflow: hidden; margin-bottom: 1.5rem;">
        <img src="${city.image_url}" alt="${city.name}" style="width: 100%; height: 100%; object-fit: cover;" />
        <div style="position: absolute; inset: 0; background: linear-gradient(180deg, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.85) 100%);"></div>
        <div style="position: absolute; bottom: 1.5rem; left: 1.5rem; right: 1.5rem; display: flex; align-items: flex-end; justify-content: space-between; color: white;">
          <div>
            <span class="badge badge-accent" style="margin-bottom: 0.4rem;">${city.state}, ${city.country}</span>
            <h2 style="font-size: 2.2rem; font-weight: 900; line-height: 1.1;">${city.name}</h2>
            <div style="font-size: 0.95rem; opacity: 0.9; margin-top: 0.25rem;">✨ ${city.specializations}</div>
          </div>
          <button id="modalFavBtn" class="btn ${city.isFavorite ? 'btn-danger active' : 'btn-secondary'}"
                  data-city-id="${city.id}"
                  onclick="citiesManager.toggleFavorite(${city.id})">
            ${city.isFavorite ? '❤️ Favorited' : '🤍 Add to Favorites'}
          </button>
        </div>
      </div>

      <!-- Key Demographic Indicators -->
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 1.5rem;">
        <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1rem; text-align: center;">
          <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Population</div>
          <div style="font-size: 1.15rem; font-weight: 800; color: var(--text-primary); margin-top: 0.25rem;">${city.population}</div>
        </div>
        <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1rem; text-align: center;">
          <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Geographic Area</div>
          <div style="font-size: 1.15rem; font-weight: 800; color: var(--text-primary); margin-top: 0.25rem;">${city.area}</div>
        </div>
        <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1rem; text-align: center;">
          <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Languages</div>
          <div style="font-size: 1.15rem; font-weight: 800; color: var(--text-primary); margin-top: 0.25rem;">${city.language}</div>
        </div>
        <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1rem; text-align: center;">
          <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Currency</div>
          <div style="font-size: 1.15rem; font-weight: 800; color: var(--text-primary); margin-top: 0.25rem;">${city.currency}</div>
        </div>
      </div>

      <!-- City Overview -->
      <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.5rem; margin-bottom: 1.5rem;">
        <h4 style="font-size: 1.1rem; font-weight: 800; margin-bottom: 0.5rem; color: var(--text-primary);">📖 City Overview</h4>
        <p style="color: var(--text-secondary); line-height: 1.7; font-size: 0.98rem;">${city.description}</p>
      </div>

      <!-- Live Weather inside Modal -->
      <div id="modalWeatherWidget" style="background: linear-gradient(135deg, rgba(37, 99, 235, 0.08) 0%, rgba(6, 182, 212, 0.08) 100%); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.5rem; margin-bottom: 1.5rem;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem;">
          <h4 style="font-size: 1.1rem; font-weight: 800; color: var(--text-primary);">⛅ Current Atmospheric Conditions</h4>
          <span class="badge badge-primary" id="modalWeatherSource">Live Station</span>
        </div>
        <div id="modalWeatherContent">
          <div class="skeleton skeleton-text" style="height: 40px;"></div>
        </div>
      </div>

      <!-- Grid for Attractions & Transportation -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
        <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.5rem;">
          <h4 style="font-size: 1.1rem; font-weight: 800; margin-bottom: 1rem; color: var(--text-primary);">🏛️ Key Attractions & Heritage</h4>
          <div style="display: flex; flex-wrap: wrap; gap: 0.6rem;">
            ${attractionsHtml}
          </div>
        </div>

        <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.5rem;">
          <h4 style="font-size: 1.1rem; font-weight: 800; margin-bottom: 1rem; color: var(--text-primary);">🚆 Transportation & Mobility Grid</h4>
          <ul style="list-style: none;">
            ${transHtml}
          </ul>
        </div>
      </div>

      <!-- Grid for Education & Healthcare -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
        <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.5rem;">
          <h4 style="font-size: 1.1rem; font-weight: 800; margin-bottom: 1rem; color: var(--text-primary);">🎓 Universities & Academic Institutions</h4>
          <div style="display: flex; flex-direction: column; gap: 0.6rem;">
            ${eduHtml}
          </div>
        </div>

        <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.5rem;">
          <h4 style="font-size: 1.1rem; font-weight: 800; margin-bottom: 1rem; color: var(--text-primary);">🏥 Healthcare & Medical Infrastructure</h4>
          <div style="display: flex; flex-direction: column; gap: 0.6rem;">
            ${healthHtml}
          </div>
        </div>
      </div>

      <!-- Economy & Industrial Drivers -->
      <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.5rem; margin-bottom: 1.5rem;">
        <h4 style="font-size: 1.1rem; font-weight: 800; margin-bottom: 0.5rem; color: var(--text-primary);">💼 Economy & Industrial Drivers</h4>
        <p style="color: var(--text-secondary); line-height: 1.65; font-size: 0.95rem;">${city.economy}</p>
      </div>

      <!-- Related News Section -->
      ${relatedNews.length > 0 ? `
        <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 1.5rem;">
          <h4 style="font-size: 1.1rem; font-weight: 800; margin-bottom: 1rem; color: var(--text-primary);">📰 Recent Civic & Smart City Updates</h4>
          <div style="display: flex; flex-direction: column; gap: 0.75rem;">
            ${relatedNews.map(n => `
              <div style="padding: 0.75rem; background: var(--bg-tertiary); border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
                <div style="display: flex; justify-content: space-between; font-size: 0.78rem; color: var(--text-muted); margin-bottom: 0.25rem;">
                  <span class="badge badge-accent">${n.category}</span>
                  <span>${new Date(n.published_at).toLocaleDateString()}</span>
                </div>
                <h5 style="font-size: 0.95rem; font-weight: 700; color: var(--text-primary); margin-bottom: 0.25rem;">${n.title}</h5>
                <p style="font-size: 0.85rem; color: var(--text-secondary);">${n.summary}</p>
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}
    `;

    // Fetch and populate modal weather widget
    this.populateModalWeather(city.name);
  },

  async populateModalWeather(cityName) {
    const wRes = await api.get(`/weather/${encodeURIComponent(cityName)}`);
    const container = document.getElementById('modalWeatherContent');
    const sourceEl = document.getElementById('modalWeatherSource');

    if (wRes.ok && wRes.data.success && wRes.data.weather && container) {
      const w = wRes.data.weather;
      if (sourceEl) sourceEl.textContent = w.source;

      container.innerHTML = `
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;">
          <div style="display: flex; align-items: center; gap: 1.25rem;">
            <div style="font-size: 3.5rem; font-weight: 900; color: var(--text-primary); line-height: 1;">
              ${w.temperature}°C
            </div>
            <div>
              <div style="font-size: 1.2rem; font-weight: 800; color: var(--text-primary);">${w.condition}</div>
              <div style="font-size: 0.85rem; color: var(--text-muted);">Feels like ${w.feelsLike}°C &bull; Updated ${w.lastUpdated}</div>
            </div>
          </div>
          <div style="display: flex; gap: 1.5rem; flex-wrap: wrap;">
            <div>
              <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700;">HUMIDITY</div>
              <div style="font-size: 1.1rem; font-weight: 800;">${w.humidity}%</div>
            </div>
            <div>
              <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700;">WIND</div>
              <div style="font-size: 1.1rem; font-weight: 800;">${w.windSpeed} km/h</div>
            </div>
            <div>
              <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700;">AIR QUALITY</div>
              <div style="font-size: 1.1rem; font-weight: 800; color: ${w.aqi < 60 ? 'var(--accent-emerald)' : 'var(--accent-amber)'};">${w.aqi} (${w.aqiCategory})</div>
            </div>
          </div>
        </div>
      `;
    }
  }
};

window.citiesManager = citiesManager;
document.addEventListener('DOMContentLoaded', () => citiesManager.init());
