/**
 * Smart City Project - Main App Controller & Router
 */

const app = {
  currentView: 'explore',

  init() {
    this.bindNavigation();
    this.handleRoute();

    window.addEventListener('hashchange', () => this.handleRoute());

    // Update copyright year
    const yr = document.getElementById('footerYear');
    if (yr) yr.textContent = new Date().getFullYear();
  },

  bindNavigation() {
    // Navigation links
    document.querySelectorAll('.nav-link[data-view]').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const view = e.currentTarget.dataset.view;
        window.location.hash = view;
        this.closeMobileMenu();
      });
    });

    // Mobile menu toggle
    const mobileBtn = document.getElementById('mobileMenuToggle');
    const navMenu = document.getElementById('navMenu');
    if (mobileBtn && navMenu) {
      mobileBtn.addEventListener('click', () => {
        navMenu.classList.toggle('mobile-open');
      });
    }
  },

  closeMobileMenu() {
    const navMenu = document.getElementById('navMenu');
    if (navMenu) navMenu.classList.remove('mobile-open');
  },

  handleRoute() {
    let hash = window.location.hash.replace('#', '').trim();
    if (!hash) hash = 'explore';

    // If navigating to admin without admin role
    if (hash === 'admin' && api.getUser()?.role !== 'admin') {
      showToast('Admin Portal', 'Please sign in with administrator credentials to access the Admin Portal.', 'info');
      if (window.auth) window.auth.showAuthModal('login');
      hash = 'explore';
    }

    this.switchView(hash);
  },

  switchView(viewName) {
    this.currentView = viewName;

    // Update active nav links
    document.querySelectorAll('.nav-link[data-view]').forEach(link => {
      link.classList.toggle('active', link.dataset.view === viewName);
    });

    // Show/hide main sections
    const views = ['explore', 'weather', 'news', 'favorites', 'admin'];
    views.forEach(v => {
      const el = document.getElementById(`view_${v}`);
      if (el) {
        el.style.display = v === viewName ? 'block' : 'none';
      }
    });

    // Scroll to top of content
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Refresh specific section data if switching to it
    if (viewName === 'favorites' && window.favoritesManager) {
      window.favoritesManager.loadFavorites();
    } else if (viewName === 'admin' && window.adminManager) {
      window.adminManager.loadAdminData();
    }
  }
};

window.app = app;
document.addEventListener('DOMContentLoaded', () => app.init());
