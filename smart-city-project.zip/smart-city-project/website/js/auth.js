/**
 * Smart City Project - Authentication & User Profile Management
 */

const auth = {
  currentUser: null,

  init() {
    this.currentUser = api.getUser();
    this.bindEvents();
    this.updateAuthUI();

    // Verify token validity in background if user exists
    if (api.getToken()) {
      this.fetchCurrentUser();
    }
  },

  bindEvents() {
    // Open Auth Modal
    const openLoginBtns = document.querySelectorAll('.open-login-btn');
    openLoginBtns.forEach(btn => {
      btn.addEventListener('click', () => this.showAuthModal('login'));
    });

    const openRegisterBtns = document.querySelectorAll('.open-register-btn');
    openRegisterBtns.forEach(btn => {
      btn.addEventListener('click', () => this.showAuthModal('register'));
    });

    // Close Modals
    const closeBtns = document.querySelectorAll('.modal-close-trigger');
    closeBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const modal = e.target.closest('.modal-backdrop');
        if (modal) modal.classList.remove('open');
      });
    });

    // Backdrop click close
    document.querySelectorAll('.modal-backdrop').forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('open');
      });
    });

    // Tab switcher in Auth Modal
    const authTabs = document.querySelectorAll('.auth-tab-btn');
    authTabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        const targetTab = e.currentTarget.dataset.tab;
        this.switchAuthTab(targetTab);
      });
    });

    // Forms
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
      loginForm.addEventListener('submit', (e) => this.handleLogin(e));
    }

    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
      registerForm.addEventListener('submit', (e) => this.handleRegister(e));
    }

    // Demo Fill Buttons
    const demoAdminBtn = document.getElementById('demoAdminBtn');
    if (demoAdminBtn) {
      demoAdminBtn.addEventListener('click', () => {
        this.switchAuthTab('login');
        document.getElementById('loginEmail').value = 'admin@smartcity.gov';
        document.getElementById('loginPassword').value = 'Admin@1234';
      });
    }

    const demoCitizenBtn = document.getElementById('demoCitizenBtn');
    if (demoCitizenBtn) {
      demoCitizenBtn.addEventListener('click', () => {
        this.switchAuthTab('login');
        document.getElementById('loginEmail').value = 'citizen@smartcity.gov';
        document.getElementById('loginPassword').value = 'Citizen@1234';
      });
    }

    // Logout
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', () => this.logout());
    }

    // Profile & Settings
    const profileBtn = document.getElementById('profileNavBtn');
    if (profileBtn) {
      profileBtn.addEventListener('click', () => this.showProfileModal());
    }

    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
      profileForm.addEventListener('submit', (e) => this.handleUpdateProfile(e));
    }

    const passwordForm = document.getElementById('passwordForm');
    if (passwordForm) {
      passwordForm.addEventListener('submit', (e) => this.handleChangePassword(e));
    }
  },

  showAuthModal(initialTab = 'login') {
    const modal = document.getElementById('authModal');
    if (!modal) return;
    this.switchAuthTab(initialTab);
    modal.classList.add('open');
  },

  switchAuthTab(tabName) {
    document.querySelectorAll('.auth-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tabName);
    });

    const loginSection = document.getElementById('loginTabSection');
    const registerSection = document.getElementById('registerTabSection');

    if (loginSection && registerSection) {
      loginSection.style.display = tabName === 'login' ? 'block' : 'none';
      registerSection.style.display = tabName === 'register' ? 'block' : 'none';
    }
  },

  async handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    const submitBtn = e.target.querySelector('button[type="submit"]');

    if (!email || !password) {
      showToast('Validation Error', 'Please enter email and password.', 'warning');
      return;
    }

    const origText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="spinner"></span> Signing in...';
    submitBtn.disabled = true;

    const res = await api.post('/auth/login', { email, password });
    submitBtn.innerHTML = origText;
    submitBtn.disabled = false;

    if (res.ok && res.data.success) {
      api.setToken(res.data.token);
      api.setUser(res.data.user);
      this.currentUser = res.data.user;

      showToast('Welcome Back!', `Signed in as ${this.currentUser.name}`, 'success');
      document.getElementById('authModal').classList.remove('open');
      this.updateAuthUI();

      // Refresh cities and favorites
      window.dispatchEvent(new CustomEvent('authChange', { detail: { user: this.currentUser } }));
    } else {
      showToast('Login Failed', res.data.message || 'Invalid credentials.', 'error');
    }
  },

  async handleRegister(e) {
    e.preventDefault();
    const name = document.getElementById('regName').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value;
    const submitBtn = e.target.querySelector('button[type="submit"]');

    if (!name || !email || !password) {
      showToast('Validation Error', 'Please complete all fields.', 'warning');
      return;
    }

    if (password.length < 6) {
      showToast('Weak Password', 'Password must be at least 6 characters.', 'warning');
      return;
    }

    const origText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="spinner"></span> Creating account...';
    submitBtn.disabled = true;

    const res = await api.post('/auth/register', { name, email, password });
    submitBtn.innerHTML = origText;
    submitBtn.disabled = false;

    if (res.ok && res.data.success) {
      api.setToken(res.data.token);
      api.setUser(res.data.user);
      this.currentUser = res.data.user;

      showToast('Welcome!', 'Your Smart City citizen account has been created.', 'success');
      document.getElementById('authModal').classList.remove('open');
      this.updateAuthUI();

      window.dispatchEvent(new CustomEvent('authChange', { detail: { user: this.currentUser } }));
    } else {
      showToast('Registration Failed', res.data.message || 'Could not register.', 'error');
    }
  },

  async fetchCurrentUser() {
    const res = await api.get('/auth/me');
    if (res.ok && res.data.success) {
      this.currentUser = res.data.user;
      api.setUser(res.data.user);
      this.updateAuthUI();
    }
  },

  logout() {
    api.clearAuth();
    this.currentUser = null;
    showToast('Signed Out', 'You have been safely logged out.', 'info');
    this.updateAuthUI();
    window.dispatchEvent(new CustomEvent('authChange', { detail: { user: null } }));
  },

  updateAuthUI() {
    const guestNav = document.getElementById('navGuestActions');
    const userNav = document.getElementById('navUserActions');
    const adminLink = document.getElementById('adminPortalNavLink');
    const userNameBadge = document.getElementById('navUserName');
    const userAvatarLetter = document.getElementById('navUserAvatarLetter');

    if (this.currentUser) {
      if (guestNav) guestNav.style.display = 'none';
      if (userNav) userNav.style.display = 'flex';
      if (userNameBadge) userNameBadge.textContent = this.currentUser.name;
      if (userAvatarLetter) userAvatarLetter.textContent = (this.currentUser.name || 'U').charAt(0).toUpperCase();

      if (adminLink) {
        adminLink.style.display = this.currentUser.role === 'admin' ? 'flex' : 'none';
      }
    } else {
      if (guestNav) guestNav.style.display = 'flex';
      if (userNav) userNav.style.display = 'none';
      if (adminLink) adminLink.style.display = 'none';
    }
  },

  showProfileModal() {
    if (!this.currentUser) return;
    const modal = document.getElementById('profileModal');
    if (!modal) return;

    document.getElementById('profileName').value = this.currentUser.name || '';
    document.getElementById('profileEmail').value = this.currentUser.email || '';
    document.getElementById('profileBio').value = this.currentUser.bio || '';
    document.getElementById('profileRoleBadge').textContent = (this.currentUser.role || 'user').toUpperCase();
    document.getElementById('profileMemberSince').textContent = this.currentUser.created_at ? new Date(this.currentUser.created_at).toLocaleDateString() : 'N/A';

    modal.classList.add('open');
  },

  async handleUpdateProfile(e) {
    e.preventDefault();
    const name = document.getElementById('profileName').value.trim();
    const bio = document.getElementById('profileBio').value.trim();

    if (!name) {
      showToast('Validation Error', 'Name cannot be empty.', 'warning');
      return;
    }

    const res = await api.put('/auth/profile', { name, bio });
    if (res.ok && res.data.success) {
      this.currentUser = res.data.user;
      api.setUser(res.data.user);
      this.updateAuthUI();
      showToast('Profile Updated', 'Your profile details were saved successfully.', 'success');
      document.getElementById('profileModal').classList.remove('open');
    } else {
      showToast('Update Failed', res.data.message || 'Could not update profile.', 'error');
    }
  },

  async handleChangePassword(e) {
    e.preventDefault();
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;

    if (!currentPassword || !newPassword) {
      showToast('Validation Error', 'Please provide both current and new password.', 'warning');
      return;
    }

    if (newPassword.length < 6) {
      showToast('Weak Password', 'New password must be at least 6 characters long.', 'warning');
      return;
    }

    const res = await api.put('/auth/password', { currentPassword, newPassword });
    if (res.ok && res.data.success) {
      showToast('Password Changed', 'Your password has been updated securely.', 'success');
      document.getElementById('currentPassword').value = '';
      document.getElementById('newPassword').value = '';
      document.getElementById('profileModal').classList.remove('open');
    } else {
      showToast('Error', res.data.message || 'Password update failed.', 'error');
    }
  }
};

window.auth = auth;
document.addEventListener('DOMContentLoaded', () => auth.init());
