/**
 * Smart City Project - Weather & Climate Station Module
 */

const weatherManager = {
  activeCity: 'Chennai',
  supportedCities: ['Chennai', 'Madurai', 'Coimbatore', 'Bengaluru', 'Mumbai', 'Delhi', 'Hyderabad'],

  init() {
    this.renderCityTabs();
    this.bindEvents();
    this.fetchWeather(this.activeCity);
  },

  bindEvents() {
    const searchForm = document.getElementById('weatherSearchForm');
    if (searchForm) {
      searchForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const input = document.getElementById('weatherCityInput');
        if (input && input.value.trim()) {
          this.activeCity = input.value.trim();
          this.updateActiveTab(this.activeCity);
          this.fetchWeather(this.activeCity);
        }
      });
    }
  },

  renderCityTabs() {
    const container = document.getElementById('weatherCityTabs');
    if (!container) return;

    container.innerHTML = this.supportedCities.map(city => `
      <button class="city-tab-btn ${city === this.activeCity ? 'active' : ''}" 
              data-city="${city}" 
              onclick="weatherManager.selectCity('${city}')">
        ${city}
      </button>
    `).join('');
  },

  selectCity(cityName) {
    this.activeCity = cityName;
    this.updateActiveTab(cityName);
    const input = document.getElementById('weatherCityInput');
    if (input) input.value = '';
    this.fetchWeather(cityName);
  },

  updateActiveTab(cityName) {
    document.querySelectorAll('.city-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.city?.toLowerCase() === cityName.toLowerCase());
    });
  },

  async fetchWeather(cityName) {
    const weatherBox = document.getElementById('weatherMainDisplay');
    if (!weatherBox) return;

    // Show loading state
    weatherBox.innerHTML = `
      <div class="loading-overlay">
        <span class="spinner spinner-lg"></span>
        <p>Connecting to meteorological stations for ${cityName}...</p>
      </div>
    `;

    const res = await api.get(`/weather/${encodeURIComponent(cityName)}`);

    if (res.ok && res.data.success && res.data.weather) {
      this.renderWeather(res.data.weather);
    } else {
      weatherBox.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">⛈️</div>
          <div class="empty-title">Weather Report Unavailable</div>
          <p class="empty-desc">${res.data.message || 'Unable to retrieve telemetry data.'}</p>
          <button class="btn btn-primary btn-sm" onclick="weatherManager.fetchWeather('${cityName}')">Retry</button>
        </div>
      `;
    }
  },

  getWeatherIcon(condition = '') {
    const c = condition.toLowerCase();
    if (c.includes('sun') || c.includes('clear')) return '☀️';
    if (c.includes('cloud') && c.includes('partly')) return '⛅';
    if (c.includes('cloud')) return '☁️';
    if (c.includes('rain') || c.includes('shower')) return '🌧️';
    if (c.includes('thunder') || c.includes('storm')) return '⛈️';
    if (c.includes('breeze') || c.includes('wind')) return '🍃';
    if (c.includes('haze') || c.includes('fog')) return '🌫️';
    return '🌤️';
  },

  renderWeather(w) {
    const weatherBox = document.getElementById('weatherMainDisplay');
    if (!weatherBox) return;

    const weatherIcon = this.getWeatherIcon(w.condition);

    weatherBox.innerHTML = `
      <div class="weather-hero-display animate-fade-in">
        <div style="display: flex; flex-direction: column; gap: 0.5rem;">
          <div style="display: flex; align-items: center; justify-content: space-between;">
            <span class="badge badge-primary">📍 ${w.cityName}</span>
            <span class="badge badge-accent">${w.source}</span>
          </div>

          <div class="weather-temp-huge">
            ${w.temperature}<span>°C</span>
          </div>

          <div class="weather-condition-title">
            <span>${weatherIcon}</span> ${w.condition}
          </div>

          <div style="font-size: 0.95rem; color: var(--text-muted); margin-top: 0.25rem;">
            Feels like <strong>${w.feelsLike}°C</strong> &bull; Synced at ${w.lastUpdated}
          </div>
        </div>

        <div class="weather-metrics-grid">
          <div class="weather-metric-cell">
            <span class="weather-metric-lbl">Humidity</span>
            <span class="weather-metric-val">💧 ${w.humidity}%</span>
          </div>
          <div class="weather-metric-cell">
            <span class="weather-metric-lbl">Wind Speed</span>
            <span class="weather-metric-val">💨 ${w.windSpeed} km/h</span>
          </div>
          <div class="weather-metric-cell">
            <span class="weather-metric-lbl">Air Quality (AQI)</span>
            <span class="weather-metric-val" style="color: ${w.aqi < 60 ? 'var(--accent-emerald)' : 'var(--accent-amber)'};">
              🌱 ${w.aqi}
            </span>
          </div>
          <div class="weather-metric-cell">
            <span class="weather-metric-lbl">Barometer</span>
            <span class="weather-metric-val">⏲️ ${w.pressure} hPa</span>
          </div>
          <div class="weather-metric-cell">
            <span class="weather-metric-lbl">Visibility</span>
            <span class="weather-metric-val">👁️ ${w.visibility}</span>
          </div>
          <div class="weather-metric-cell">
            <span class="weather-metric-lbl">UV Index</span>
            <span class="weather-metric-val">☀️ ${w.uvIndex} (Mod)</span>
          </div>
        </div>
      </div>

      <!-- 5-Day Forecast -->
      <div style="margin-top: 2rem;">
        <h4 style="font-size: 1.15rem; font-weight: 800; color: var(--text-primary); margin-bottom: 1.25rem; display: flex; align-items: center; gap: 0.5rem;">
          <span>📅</span> 5-Day Meteorological Outlook for ${w.cityName}
        </h4>
        <div class="forecast-strip">
          ${(w.forecast || []).map(f => `
            <div class="forecast-card">
              <div class="forecast-day">${f.day}</div>
              <div class="forecast-icon">${this.getWeatherIcon(f.condition)}</div>
              <div class="forecast-temps">
                <span class="forecast-high">${f.maxTemp}°</span>
                <span class="forecast-low">${f.minTemp}°</span>
              </div>
              <div class="forecast-cond">${f.condition}</div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }
};

window.weatherManager = weatherManager;
document.addEventListener('DOMContentLoaded', () => weatherManager.init());
