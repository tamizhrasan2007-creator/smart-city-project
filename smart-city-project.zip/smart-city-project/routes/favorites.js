const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { authenticateToken } = require('../middleware/auth');

// Get all favorite cities of logged-in user
router.get('/', authenticateToken, (req, res) => {
  try {
    const favorites = db.prepare(`
      SELECT c.*, f.created_at as favorited_at
      FROM favorites f
      JOIN cities c ON f.city_id = c.id
      WHERE f.user_id = ?
      ORDER BY f.created_at DESC
    `).all(req.user.id);

    const formatted = favorites.map(city => {
      let attractions = [];
      try {
        attractions = typeof city.attractions === 'string' ? JSON.parse(city.attractions) : city.attractions;
      } catch {
        attractions = (city.attractions || '').split('\n').filter(Boolean);
      }

      return {
        ...city,
        attractions,
        isFavorite: true
      };
    });

    return res.json({
      success: true,
      count: formatted.length,
      favorites: formatted
    });
  } catch (error) {
    console.error('Get favorites error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve favorites.' });
  }
});

// Toggle favorite status for a city
router.post('/toggle', authenticateToken, (req, res) => {
  try {
    const { cityId } = req.body;
    if (!cityId) {
      return res.status(400).json({ success: false, message: 'cityId is required.' });
    }

    const city = db.prepare('SELECT id, name FROM cities WHERE id = ?').get(cityId);
    if (!city) {
      return res.status(404).json({ success: false, message: 'City not found.' });
    }

    const existing = db.prepare('SELECT id FROM favorites WHERE user_id = ? AND city_id = ?').get(req.user.id, city.id);

    if (existing) {
      db.prepare('DELETE FROM favorites WHERE id = ?').run(existing.id);
      return res.json({
        success: true,
        isFavorite: false,
        message: `${city.name} removed from your favorites.`
      });
    } else {
      db.prepare('INSERT INTO favorites (user_id, city_id) VALUES (?, ?)').run(req.user.id, city.id);
      return res.json({
        success: true,
        isFavorite: true,
        message: `${city.name} added to your favorites!`
      });
    }
  } catch (error) {
    console.error('Toggle favorite error:', error);
    return res.status(500).json({ success: false, message: 'Failed to update favorite status.' });
  }
});

module.exports = router;
