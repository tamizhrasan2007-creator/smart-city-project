const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

// GET /api/news - List news with filters
router.get('/', async (req, res) => {
  try {
    const { cityId, cityName, category, search, limit = 20 } = req.query;

    let query = `
      SELECT n.*, c.name as city_name, c.state as city_state
      FROM news n
      LEFT JOIN cities c ON n.city_id = c.id
      WHERE 1=1
    `;
    const params = [];

    if (cityId) {
      query += ` AND n.city_id = ?`;
      params.push(cityId);
    } else if (cityName && cityName.trim() !== '') {
      const city = db.prepare('SELECT id FROM cities WHERE name LIKE ?').get(cityName.trim());
      if (city) {
        query += ` AND n.city_id = ?`;
        params.push(city.id);
      }
    }

    if (category && category !== 'All') {
      query += ` AND n.category = ?`;
      params.push(category);
    }

    if (search && search.trim() !== '') {
      const s = `%${search.trim()}%`;
      query += ` AND (n.title LIKE ? OR n.summary LIKE ? OR n.content LIKE ?)`;
      params.push(s, s, s);
    }

    query += ` ORDER BY n.published_at DESC LIMIT ?`;
    params.push(Number(limit));

    const newsList = db.prepare(query).all(...params);

    // If external News API is configured, attempt fetching live articles as well
    const apiKey = process.env.NEWS_API_KEY;
    if (apiKey && apiKey.trim().length > 0 && cityName) {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 3500);

        const url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(cityName + ' smart city OR development')}&apiKey=${apiKey}&pageSize=5&sortBy=publishedAt`;
        const apiRes = await fetch(url, { signal: controller.signal });
        clearTimeout(timeout);

        if (apiRes.ok) {
          const apiData = await apiRes.json();
          if (apiData.articles && apiData.articles.length > 0) {
            const externalItems = apiData.articles.map((art, idx) => ({
              id: `ext-${idx}`,
              city_id: cityId || null,
              city_name: cityName,
              title: art.title,
              summary: art.description || art.title,
              content: art.content || art.description || '',
              category: 'Global News Wire',
              source: art.source?.name || 'NewsAPI',
              image_url: art.urlToImage || 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?auto=format&fit=crop&w=800&q=80',
              published_at: art.publishedAt || new Date().toISOString()
            }));

            return res.json({
              success: true,
              count: newsList.length + externalItems.length,
              source: 'Hybrid (Database + NewsAPI)',
              news: [...externalItems, ...newsList]
            });
          }
        }
      } catch (err) {
        console.warn('News API fetch failed, serving curated database articles:', err.message);
      }
    }

    return res.json({
      success: true,
      count: newsList.length,
      source: 'Smart City Verified News Network',
      news: newsList
    });
  } catch (error) {
    console.error('List news error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve news articles.' });
  }
});

// GET /api/news/:id - Single news detail
router.get('/:id', (req, res) => {
  try {
    const item = db.prepare(`
      SELECT n.*, c.name as city_name, c.state as city_state
      FROM news n
      LEFT JOIN cities c ON n.city_id = c.id
      WHERE n.id = ?
    `).get(req.params.id);

    if (!item) {
      return res.status(404).json({ success: false, message: 'News article not found.' });
    }

    return res.json({
      success: true,
      news: item
    });
  } catch (error) {
    console.error('Get news detail error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve article.' });
  }
});

// POST /api/news - Create news article (Admin only)
router.post('/', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { city_id, title, summary, content, category, source, image_url } = req.body;

    if (!title || !summary || !content) {
      return res.status(400).json({ success: false, message: 'Title, summary, and content are required.' });
    }

    const insert = db.prepare(`
      INSERT INTO news (city_id, title, summary, content, category, source, image_url, published_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    `);

    const result = insert.run(
      city_id ? Number(city_id) : null,
      title.trim(),
      summary.trim(),
      content.trim(),
      (category || 'Urban Development').trim(),
      (source || 'Smart City Press').trim(),
      (image_url || 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80').trim()
    );

    const newId = Number(result.lastInsertRowid);
    const created = db.prepare('SELECT * FROM news WHERE id = ?').get(newId);

    return res.status(201).json({
      success: true,
      message: 'News article published successfully!',
      news: created
    });
  } catch (error) {
    console.error('Create news error:', error);
    return res.status(500).json({ success: false, message: 'Failed to publish news article.' });
  }
});

// DELETE /api/news/:id - Delete news article (Admin only)
router.delete('/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const news = db.prepare('SELECT id, title FROM news WHERE id = ?').get(req.params.id);
    if (!news) {
      return res.status(404).json({ success: false, message: 'News article not found.' });
    }

    db.prepare('DELETE FROM news WHERE id = ?').run(news.id);

    return res.json({
      success: true,
      message: `Article "${news.title}" deleted successfully.`
    });
  } catch (error) {
    console.error('Delete news error:', error);
    return res.status(500).json({ success: false, message: 'Failed to delete news article.' });
  }
});

module.exports = router;
