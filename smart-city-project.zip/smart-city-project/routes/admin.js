const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

// All admin routes require admin authentication
router.use(authenticateToken, requireAdmin);

// GET /api/admin/stats - Overview statistics
router.get('/stats', (req, res) => {
  try {
    const totalCities = db.prepare('SELECT COUNT(*) as count FROM cities').get().count;
    const totalUsers = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
    const totalFavorites = db.prepare('SELECT COUNT(*) as count FROM favorites').get().count;
    const totalNews = db.prepare('SELECT COUNT(*) as count FROM news').get().count;

    // Distribution by state
    const citiesByState = db.prepare(`
      SELECT state, COUNT(*) as count
      FROM cities
      GROUP BY state
      ORDER BY count DESC
    `).all();

    // Most favorited cities
    const topFavorited = db.prepare(`
      SELECT c.name, c.state, COUNT(f.id) as favorite_count
      FROM cities c
      LEFT JOIN favorites f ON c.id = f.city_id
      GROUP BY c.id
      ORDER BY favorite_count DESC
      LIMIT 5
    `).all();

    // Recent news
    const recentNews = db.prepare(`
      SELECT n.id, n.title, n.category, n.published_at, c.name as city_name
      FROM news n
      LEFT JOIN cities c ON n.city_id = c.id
      ORDER BY n.published_at DESC
      LIMIT 5
    `).all();

    return res.json({
      success: true,
      stats: {
        totalCities,
        totalUsers,
        totalFavorites,
        totalNews,
        citiesByState,
        topFavorited,
        recentNews
      }
    });
  } catch (error) {
    console.error('Admin stats error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve stats.' });
  }
});

// GET /api/admin/users - List all users
router.get('/users', (req, res) => {
  try {
    const users = db.prepare(`
      SELECT u.id, u.name, u.email, u.role, u.bio, u.created_at,
             COUNT(f.id) as favorites_count
      FROM users u
      LEFT JOIN favorites f ON u.id = f.user_id
      GROUP BY u.id
      ORDER BY u.id ASC
    `).all();

    return res.json({
      success: true,
      count: users.length,
      users
    });
  } catch (error) {
    console.error('Admin list users error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve users.' });
  }
});

// PUT /api/admin/users/:id/role - Toggle user role
router.put('/users/:id/role', (req, res) => {
  try {
    const targetUserId = Number(req.params.id);
    const { role } = req.body;

    if (!role || (role !== 'admin' && role !== 'user')) {
      return res.status(400).json({ success: false, message: 'Role must be either "admin" or "user".' });
    }

    if (targetUserId === req.user.id && role !== 'admin') {
      return res.status(400).json({ success: false, message: 'You cannot revoke your own administrator privileges.' });
    }

    const user = db.prepare('SELECT id, name, email FROM users WHERE id = ?').get(targetUserId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, targetUserId);

    return res.json({
      success: true,
      message: `User ${user.name} role changed to ${role}.`
    });
  } catch (error) {
    console.error('Change role error:', error);
    return res.status(500).json({ success: false, message: 'Failed to change user role.' });
  }
});

// DELETE /api/admin/users/:id - Delete a user
router.delete('/users/:id', (req, res) => {
  try {
    const targetUserId = Number(req.params.id);

    if (targetUserId === req.user.id) {
      return res.status(400).json({ success: false, message: 'You cannot delete your own account while logged in as admin.' });
    }

    const user = db.prepare('SELECT id, name FROM users WHERE id = ?').get(targetUserId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    db.prepare('DELETE FROM users WHERE id = ?').run(targetUserId);

    return res.json({
      success: true,
      message: `User ${user.name} was successfully deleted.`
    });
  } catch (error) {
    console.error('Delete user error:', error);
    return res.status(500).json({ success: false, message: 'Failed to delete user.' });
  }
});

module.exports = router;
