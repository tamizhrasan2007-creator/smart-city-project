const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { authenticateToken, requireAdmin, optionalAuth } = require('../middleware/auth');

function formatCityResponse(city, isFavorite = false) {
  let attractions = [];
  try {
    attractions = typeof city.attractions === 'string' ? JSON.parse(city.attractions) : city.attractions;
  } catch {
    attractions = (city.attractions || '').split('\n').map(s => s.trim()).filter(Boolean);
  }

  let transportation = {};
  try {
    transportation = typeof city.transportation === 'string' ? JSON.parse(city.transportation) : city.transportation;
  } catch {
    transportation = { general: city.transportation };
  }

  let education = [];
  try {
    education = typeof city.education === 'string' ? JSON.parse(city.education) : city.education;
  } catch {
    education = (city.education || '').split('\n').map(s => s.trim()).filter(Boolean);
  }

  let healthcare = [];
  try {
    healthcare = typeof city.healthcare === 'string' ? JSON.parse(city.healthcare) : city.healthcare;
  } catch {
    healthcare = (city.healthcare || '').split('\n').map(s => s.trim()).filter(Boolean);
  }

  return {
    ...city,
    attractions,
    transportation,
    education,
    healthcare,
    isFavorite: Boolean(isFavorite)
  };
}

// GET /api/cities - List all cities with search and filter
router.get('/', optionalAuth, (req, res) => {
  try {
    const { search, state, sortBy } = req.query;
    let query = 'SELECT * FROM cities WHERE 1=1';
    const params = [];

    if (search && search.trim() !== '') {
      const s = `%${search.trim()}%`;
      query += ` AND (name LIKE ? OR state LIKE ? OR specializations LIKE ? OR description LIKE ? OR attractions LIKE ?)`;
      params.push(s, s, s, s, s);
    }

    if (state && state.trim() !== '' && state.toLowerCase() !== 'all') {
      query += ` AND state = ?`;
      params.push(state.trim());
    }

    if (sortBy === 'name_desc') {
      query += ' ORDER BY name DESC';
    } else if (sortBy === 'newest') {
      query += ' ORDER BY id DESC';
    } else {
      query += ' ORDER BY name ASC';
    }

    const cities = db.prepare(query).all(...params);

    // If user is authenticated, determine favorites
    let userFavs = new Set();
    if (req.user) {
      const favRows = db.prepare('SELECT city_id FROM favorites WHERE user_id = ?').all(req.user.id);
      userFavs = new Set(favRows.map(f => f.city_id));
    }

    const formatted = cities.map(c => formatCityResponse(c, userFavs.has(c.id)));

    // Also get distinct states for filter dropdown
    const states = db.prepare('SELECT DISTINCT state FROM cities ORDER BY state ASC').all().map(r => r.state);

    return res.json({
      success: true,
      count: formatted.length,
      states,
      cities: formatted
    });
  } catch (error) {
    console.error('List cities error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve cities.' });
  }
});

// GET /api/cities/:id - Get specific city details
router.get('/:id', optionalAuth, (req, res) => {
  try {
    const city = db.prepare('SELECT * FROM cities WHERE id = ?').get(req.params.id);
    if (!city) {
      return res.status(404).json({ success: false, message: 'City not found.' });
    }

    let isFavorite = false;
    if (req.user) {
      const fav = db.prepare('SELECT id FROM favorites WHERE user_id = ? AND city_id = ?').get(req.user.id, city.id);
      isFavorite = Boolean(fav);
    }

    // Get city-specific news
    const news = db.prepare('SELECT * FROM news WHERE city_id = ? ORDER BY published_at DESC LIMIT 5').all(city.id);

    return res.json({
      success: true,
      city: formatCityResponse(city, isFavorite),
      relatedNews: news
    });
  } catch (error) {
    console.error('Get city details error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve city details.' });
  }
});

// POST /api/cities - Add new city (Admin only)
router.post('/', authenticateToken, requireAdmin, (req, res) => {
  try {
    const {
      name, state, country, description, population, area,
      language, currency, attractions, transportation, education,
      healthcare, economy, specializations, image_url, latitude, longitude
    } = req.body;

    if (!name || !state || !description || !population) {
      return res.status(400).json({ success: false, message: 'Name, state, description, and population are required fields.' });
    }

    // Format attractions, transportation, education, healthcare if passed as objects or arrays
    const formattedAttractions = typeof attractions === 'string' ? attractions : JSON.stringify(attractions || []);
    const formattedTrans = typeof transportation === 'string' ? transportation : JSON.stringify(transportation || {});
    const formattedEdu = typeof education === 'string' ? education : JSON.stringify(education || []);
    const formattedHealth = typeof healthcare === 'string' ? healthcare : JSON.stringify(healthcare || []);

    const insert = db.prepare(`
      INSERT INTO cities (
        name, state, country, description, population, area,
        language, currency, attractions, transportation, education,
        healthcare, economy, specializations, image_url, latitude, longitude
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = insert.run(
      name.trim(),
      state.trim(),
      (country || 'India').trim(),
      description.trim(),
      population.trim(),
      (area || 'N/A').trim(),
      (language || 'English').trim(),
      (currency || 'INR (₹)').trim(),
      formattedAttractions,
      formattedTrans,
      formattedEdu,
      formattedHealth,
      (economy || 'Diverse commercial and industrial hub').trim(),
      (specializations || 'Smart City').trim(),
      (image_url || 'https://images.unsplash.com/photo-1477959858617-67f30bc75b82?auto=format&fit=crop&w=1200&q=80').trim(),
      parseFloat(latitude) || 0,
      parseFloat(longitude) || 0
    );

    const newId = Number(result.lastInsertRowid);
    const newCity = db.prepare('SELECT * FROM cities WHERE id = ?').get(newId);

    return res.status(201).json({
      success: true,
      message: `${name} has been added to Smart City database!`,
      city: formatCityResponse(newCity)
    });
  } catch (error) {
    console.error('Create city error:', error);
    return res.status(500).json({ success: false, message: 'Failed to create city.' });
  }
});

// PUT /api/cities/:id - Edit city (Admin only)
router.put('/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const city = db.prepare('SELECT * FROM cities WHERE id = ?').get(req.params.id);
    if (!city) {
      return res.status(404).json({ success: false, message: 'City not found.' });
    }

    const {
      name, state, country, description, population, area,
      language, currency, attractions, transportation, education,
      healthcare, economy, specializations, image_url, latitude, longitude
    } = req.body;

    const formattedAttractions = typeof attractions === 'string' ? attractions : JSON.stringify(attractions || []);
    const formattedTrans = typeof transportation === 'string' ? transportation : JSON.stringify(transportation || {});
    const formattedEdu = typeof education === 'string' ? education : JSON.stringify(education || []);
    const formattedHealth = typeof healthcare === 'string' ? healthcare : JSON.stringify(healthcare || []);

    db.prepare(`
      UPDATE cities SET
        name = ?, state = ?, country = ?, description = ?, population = ?, area = ?,
        language = ?, currency = ?, attractions = ?, transportation = ?, education = ?,
        healthcare = ?, economy = ?, specializations = ?, image_url = ?, latitude = ?, longitude = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      name || city.name,
      state || city.state,
      country || city.country,
      description || city.description,
      population || city.population,
      area || city.area,
      language || city.language,
      currency || city.currency,
      formattedAttractions,
      formattedTrans,
      formattedEdu,
      formattedHealth,
      economy || city.economy,
      specializations || city.specializations,
      image_url || city.image_url,
      latitude !== undefined ? parseFloat(latitude) : city.latitude,
      longitude !== undefined ? parseFloat(longitude) : city.longitude,
      city.id
    );

    const updated = db.prepare('SELECT * FROM cities WHERE id = ?').get(city.id);
    return res.json({
      success: true,
      message: `${updated.name} updated successfully.`,
      city: formatCityResponse(updated)
    });
  } catch (error) {
    console.error('Update city error:', error);
    return res.status(500).json({ success: false, message: 'Failed to update city.' });
  }
});

// DELETE /api/cities/:id - Delete city (Admin only)
router.delete('/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const city = db.prepare('SELECT id, name FROM cities WHERE id = ?').get(req.params.id);
    if (!city) {
      return res.status(404).json({ success: false, message: 'City not found.' });
    }

    db.prepare('DELETE FROM cities WHERE id = ?').run(city.id);

    return res.json({
      success: true,
      message: `${city.name} deleted successfully.`
    });
  } catch (error) {
    console.error('Delete city error:', error);
    return res.status(500).json({ success: false, message: 'Failed to delete city.' });
  }
});

module.exports = router;
