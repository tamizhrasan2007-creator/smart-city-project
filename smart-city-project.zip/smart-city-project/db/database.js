const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const bcrypt = require('bcryptjs');

const dbPath = path.join(__dirname, 'smartcity.db');
const db = new DatabaseSync(dbPath);

// Enable foreign keys
db.exec('PRAGMA foreign_keys = ON;');

// Initialize tables
function initializeDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL COLLATE NOCASE,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      bio TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS cities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      state TEXT NOT NULL,
      country TEXT NOT NULL DEFAULT 'India',
      description TEXT NOT NULL,
      population TEXT NOT NULL,
      area TEXT NOT NULL,
      language TEXT NOT NULL,
      currency TEXT NOT NULL DEFAULT 'INR (₹)',
      attractions TEXT NOT NULL,
      transportation TEXT NOT NULL,
      education TEXT NOT NULL,
      healthcare TEXT NOT NULL,
      economy TEXT NOT NULL,
      specializations TEXT NOT NULL,
      image_url TEXT NOT NULL,
      latitude REAL DEFAULT 0,
      longitude REAL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS favorites (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      city_id INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(user_id, city_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (city_id) REFERENCES cities(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS news (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      city_id INTEGER,
      title TEXT NOT NULL,
      summary TEXT NOT NULL,
      content TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'Urban Development',
      source TEXT NOT NULL DEFAULT 'Smart City Newsroom',
      image_url TEXT DEFAULT '',
      published_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (city_id) REFERENCES cities(id) ON DELETE SET NULL
    );
  `);

  seedData();
}

function seedData() {
  // Check users count
  const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
  if (userCount === 0) {
    console.log('Seeding initial users...');
    const adminPassHash = bcrypt.hashSync('Admin@1234', 10);
    const userPassHash = bcrypt.hashSync('Citizen@1234', 10);

    const insertUser = db.prepare(`
      INSERT INTO users (name, email, password, role, bio)
      VALUES (?, ?, ?, ?, ?)
    `);

    insertUser.run(
      'Administrator',
      'admin@smartcity.gov',
      adminPassHash,
      'admin',
      'Chief Urban Development & Municipal Affairs Lead'
    );

    insertUser.run(
      'Citizen User',
      'citizen@smartcity.gov',
      userPassHash,
      'user',
      'Active citizen and urban sustainability enthusiast'
    );
  }

  // Check cities count
  const cityCount = db.prepare('SELECT COUNT(*) as count FROM cities').get().count;
  if (cityCount === 0) {
    console.log('Seeding initial sample cities...');
    const insertCity = db.prepare(`
      INSERT INTO cities (
        name, state, country, description, population, area,
        language, currency, attractions, transportation, education,
        healthcare, economy, specializations, image_url, latitude, longitude
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const sampleCities = [
      {
        name: 'Chennai',
        state: 'Tamil Nadu',
        country: 'India',
        description: 'Known as the Gateway to South India and the Detroit of Asia, Chennai is a vibrant metropolis blending rich classical Dravidian culture, music festivals, and scenic coastlines with a powerhouse automobile, SaaS, and manufacturing economy.',
        population: '11.5 Million (Metropolitan)',
        area: '426 sq km',
        language: 'Tamil, English',
        currency: 'INR (₹)',
        attractions: JSON.stringify([
          'Marina Beach (World\'s 2nd longest natural urban beach)',
          'Kapaleeshwarar 7th-century Temple',
          'Fort St. George & Clive Museum',
          'San Thome Cathedral Basilica',
          'Guindy National Park & Snake Park',
          'DakshinaChitra Heritage Museum',
          'Government Museum Egmore'
        ]),
        transportation: JSON.stringify({
          air: 'Chennai International Airport (MAA) - 4th busiest hub in India',
          rail: 'Chennai Central (Puratchi Thalaivar Dr. MGR) & Egmore Junctions connecting nationwide',
          metro: 'Chennai Metro Rail (CMRL) Phase 1 operational, Phase 2 (118.9 km) under construction',
          road: 'Chennai Mofussil Bus Terminus (CMBT & Kilambakkam KCBT), Grand Southern Trunk Road (NH 45)',
          port: 'Port of Chennai & Ennore Kamarajar Port for international freight'
        }),
        education: JSON.stringify([
          'Indian Institute of Technology Madras (IIT Madras - Top Ranked in NIRF)',
          'Anna University College of Engineering Guindy',
          'Madras Medical College (Founded 1835)',
          'Loyola College & Presidency College',
          'National Institute of Fashion Technology (NIFT)'
        ]),
        healthcare: JSON.stringify([
          'Apollo Hospitals (Greams Road flagship)',
          'MIOT International Institute of Orthopaedics',
          'Fortis Malar Hospital & Dr. Rela Institute',
          'Cancer Institute (WIA) Adyar',
          'Government General Hospital (Rajiv Gandhi)'
        ]),
        economy: 'Major automobile hub manufacturing over 40% of India\'s passenger cars and commercial vehicles. Booming Software-as-a-Service (SaaS capital of India housing Zoho & Freshworks), hardware electronics manufacturing, and seaport shipping logistics.',
        specializations: 'Detroit of Asia, Healthcare Capital of India, Carnatic Music & UNESCO Creative Cities Network, SaaS Capital',
        image_url: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=1200&q=80',
        latitude: 13.0827,
        longitude: 80.2707
      },
      {
        name: 'Madurai',
        state: 'Tamil Nadu',
        country: 'India',
        description: 'One of the oldest continuously inhabited cities in the world, Madurai is the soul of Tamil culture. Built around the historic Meenakshi Amman Temple in concentric lotus-petal streets, it is famed for fragrant jasmine, night bazaars, and traditional hospitality.',
        population: '1.8 Million',
        area: '148 sq km',
        language: 'Tamil, English',
        currency: 'INR (₹)',
        attractions: JSON.stringify([
          'Meenakshi Sundareswarar Historic Temple with iconic gopurams',
          'Thirumalai Nayakkar Palace (17th-century Indo-Saracenic)',
          'Gandhi Memorial Museum (Tamukkam Palace)',
          'Alagar Koyil Vishnu Temple in green foothills',
          'Vandiyur Mariamman Teppakulam (Giant temple pond)',
          'Koodal Azhagar Temple'
        ]),
        transportation: JSON.stringify({
          air: 'Madurai Airport (IXM) with domestic flights and international links to Colombo & Dubai',
          rail: 'Madurai Junction (MDU) - A1 grade major railway junction in Southern Railway',
          metro: 'Madurai Metro Light Rail transit system currently in detailed project report stage',
          road: 'Integrated bus terminals at Mattuthavani (MGR Bus Stand), Arappalayam, and Periyar',
          highways: 'Located on prime North-South Golden Quadrilateral corridor NH 44 and NH 85'
        }),
        education: JSON.stringify([
          'Madurai Kamaraj University (MKU)',
          'Thiagarajar College of Engineering (TCE)',
          'Madurai Medical College',
          'The American College (Founded 1881)',
          'Lady Doak College'
        ]),
        healthcare: JSON.stringify([
          'Aravind Eye Care System (World-renowned ophthalmology pioneer)',
          'Government Rajaji Hospital (GRH tertiary care)',
          'Apollo Speciality Hospital Madurai',
          'Meenakshi Mission Hospital and Research Centre',
          'Vadamalayan Hospitals'
        ]),
        economy: 'Prominent center for textile spinning, handloom cotton, rubber manufacturing, agricultural trading, and fragrant Madurai Malli (GI Tagged Jasmine) exports. Growing Tier-2 IT corridor with ELCOT IT Park.',
        specializations: 'Athens of the East, Thoonga Nagaram (City That Never Sleeps), Temple City, Jasmine Capital',
        image_url: 'https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=1200&q=80',
        latitude: 9.9252,
        longitude: 78.1198
      },
      {
        name: 'Coimbatore',
        state: 'Tamil Nadu',
        country: 'India',
        description: 'Nestled on the banks of the Noyyal River flanked by the Western Ghats, Coimbatore is an industrial powerhouse renowned for its pleasant weather, entrepreneurial spirit, precision engineering foundries, and lush textile mills.',
        population: '2.9 Million',
        area: '246 sq km',
        language: 'Tamil, English',
        currency: 'INR (₹)',
        attractions: JSON.stringify([
          '112-foot Adiyogi Shiva Statue at Isha Yoga Center',
          'Marudhamalai Murugan Hill Temple',
          'Siruvani Waterfalls & Dam (World\'s 2nd tastiest water)',
          'Gass Forest Museum of Forestry',
          'VOC Park and Zoo',
          'G.D. Naidu Car Museum & Industrial Heritage Centre'
        ]),
        transportation: JSON.stringify({
          air: 'Coimbatore International Airport (Peelamedu - CJB)',
          rail: 'Coimbatore Junction (CBE) - high-revenue southern railway hub',
          metro: 'Coimbatore Metro Rail Corridor planned across Avinashi and Trichy roads',
          road: 'Gandhipuram Central Bus Stand, Singanallur & Ukkadam Bus Terminals',
          expressways: 'Avinashi Road Elevated Expressway (10 km corridor)'
        }),
        education: JSON.stringify([
          'PSG College of Technology',
          'Tamil Nadu Agricultural University (TNAU)',
          'Coimbatore Institute of Technology (CIT)',
          'Amrita Vishwa Vidyapeetham',
          'Government College of Technology (GCT)'
        ]),
        healthcare: JSON.stringify([
          'Kovai Medical Center and Hospital (KMCH)',
          'Ganga Hospital (World leader in trauma & orthopaedic surgery)',
          'Sri Ramakrishna Hospital',
          'G. Kuppuswamy Naidu Memorial Hospital (GKNM)',
          'PSG Hospitals'
        ]),
        economy: 'Supplies over 50% of India\'s motors and water pump sets. World-class textile machinery, yarn production, casting foundries, auto-components, jewellery manufacturing, and emerging IT SEZs (TIDEL Park Coimbatore).',
        specializations: 'Manchester of South India, Pump City of India, Textile & Foundry Capital, Western Ghats Gateway',
        image_url: 'https://images.unsplash.com/photo-1589308078059-be1415eab4c3?auto=format&fit=crop&w=1200&q=80',
        latitude: 11.0168,
        longitude: 76.9558
      },
      {
        name: 'Bengaluru',
        state: 'Karnataka',
        country: 'India',
        description: 'Perched on the Deccan Plateau, Bengaluru is India\'s high-tech epicenter. Renowned for its cosmopolitan culture, lush public gardens, microbreweries, and world-class research institutes, it is the premier technology startup capital of Asia.',
        population: '13.6 Million',
        area: '741 sq km',
        language: 'Kannada, English, Hindi',
        currency: 'INR (₹)',
        attractions: JSON.stringify([
          'Lalbagh Botanical Garden & 19th-century Glass House',
          'Cubbon Park green canopy & State Central Library',
          'Bangalore Palace (Tudor-style royal estate)',
          'Vidhana Soudha (Neo-Dravidian legislative seat)',
          'Bannerghatta National Park & Safari',
          'HAL Aerospace Museum & Heritage Centre',
          'ISKCON Temple Bangalore'
        ]),
        transportation: JSON.stringify({
          air: 'Kempegowda International Airport (BLR) - World\'s most beautiful terminal T2',
          rail: 'KSR Bengaluru City Railway Station & Yesvantpur Junction',
          metro: 'Namma Metro (Purple, Green, Yellow, and Blue airport corridors)',
          road: 'BMTC Air-Conditioned Vajra bus system, Outer Ring Road expressway',
          commuter: 'Bengaluru Suburban Rail Project (BSRP) under execution'
        }),
        education: JSON.stringify([
          'Indian Institute of Science (IISc Bangalore)',
          'Indian Institute of Management Bangalore (IIMB)',
          'National Law School of India University (NLSIU)',
          'RV College of Engineering & PES University',
          'International Institute of Information Technology (IIIT-B)'
        ]),
        healthcare: JSON.stringify([
          'Manipal Hospitals (Old Airport Road)',
          'Narayana Health City (Cardiac center of excellence)',
          'Fortis Hospital Bannerghatta Road',
          'NIMHANS (National Institute of Mental Health and Neurosciences)',
          'Aster CMI Hospital'
        ]),
        economy: 'Contributes over 38% of India\'s total IT software exports. Headquarters of Infosys, Wipro, Flipkart, Swiggy, ISRO, and global R&D engineering centers for Google, Microsoft, Amazon, Intel, and Apple.',
        specializations: 'Silicon Valley of India, Garden City, Pub Capital, DeepTech & Unicorn Startup Epicenter',
        image_url: 'https://images.unsplash.com/photo-1596176530529-78163a4f7af2?auto=format&fit=crop&w=1200&q=80',
        latitude: 12.9716,
        longitude: 77.5946
      },
      {
        name: 'Mumbai',
        state: 'Maharashtra',
        country: 'India',
        description: 'The pulsing heartbeat of Indian commerce and cinema, Mumbai is a coastal mega-city that never sleeps. Home to grand colonial architecture, historic sea promenades, billionaire towers, and Bollywood dreams, it generates substantial national revenue.',
        population: '21.3 Million (MMR)',
        area: '603 sq km',
        language: 'Marathi, Hindi, English',
        currency: 'INR (₹)',
        attractions: JSON.stringify([
          'Gateway of India overlooking the Arabian Sea',
          'Marine Drive (The Queen\'s Necklace promenade)',
          'Chhatrapati Shivaji Maharaj Terminus (UNESCO World Heritage)',
          'Bandra-Worli Sea Link architectural marvel',
          'Elephanta Caves island rock-cut sculptures',
          'Sanjay Gandhi National Park & Kanheri Caves',
          'Chhatrapati Shivaji Maharaj Vastu Sangrahalaya Museum'
        ]),
        transportation: JSON.stringify({
          air: 'Chhatrapati Shivaji Maharaj International Airport (BOM) & upcoming Navi Mumbai (NMI)',
          rail: 'Mumbai Suburban Railway carrying over 7.5 million passengers daily',
          metro: 'Mumbai Metro Lines 1, 2A, 7, and Aqua Line 3 underground network',
          sea: 'Atal Setu (MTHL - 21.8 km trans-harbour sea bridge) & Ro-Pax ferries',
          bus: 'BEST electric double-decker buses and intercity AC services'
        }),
        education: JSON.stringify([
          'Indian Institute of Technology Bombay (IIT Bombay)',
          'University of Mumbai (Established 1857)',
          'Tata Institute of Fundamental Research (TIFR)',
          'St. Xavier\'s College & Jamnalal Bajaj Institute (JBIMS)',
          'Grant Government Medical College & Sir JJ Hospital'
        ]),
        healthcare: JSON.stringify([
          'Lilavati Hospital and Research Centre Bandra',
          'Kokilaben Dhirubhai Ambani Hospital Andheri',
          'Tata Memorial Centre (Premier cancer treatment hub)',
          'Breach Candy Hospital & Hinduja Hospital',
          'King Edward Memorial (KEM) Hospital'
        ]),
        economy: 'Financial capital of India housing the Reserve Bank of India (RBI), Bombay Stock Exchange (BSE), National Stock Exchange (NSE), Bollywood film industry, major banking headquarters, and Jawaharlal Nehru Port (JNPT).',
        specializations: 'Financial Capital of India, City of Dreams, Bollywood Cinema Hub, Maximum City',
        image_url: 'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?auto=format&fit=crop&w=1200&q=80',
        latitude: 19.076,
        longitude: 72.8777
      },
      {
        name: 'Delhi',
        state: 'Delhi NCR',
        country: 'India',
        description: 'India\'s historic and political capital, Delhi is a grand tapestry of ancient empires, mughal monuments, sprawling boulevards, vibrant bazaars, and modern governance. It serves as the primary diplomatic and administrative center of the nation.',
        population: '33 Million (National Capital Region)',
        area: '1,484 sq km',
        language: 'Hindi, English, Punjabi, Urdu',
        currency: 'INR (₹)',
        attractions: JSON.stringify([
          'Red Fort (Lal Qila - UNESCO World Heritage)',
          'India Gate & National War Memorial',
          'Qutub Minar 73-meter minaret complex',
          'Humayun\'s Tomb garden mausoleum',
          'Lotus Temple (Bahá\'í House of Worship)',
          'Swaminarayan Akshardham Temple complex',
          'Chandni Chowk heritage food and spice lanes'
        ]),
        transportation: JSON.stringify({
          air: 'Indira Gandhi International Airport (DEL) - World-class hub with 3 massive terminals',
          rail: 'New Delhi (NDLS), Old Delhi, Hazrat Nizamuddin, and Anand Vihar Terminals',
          metro: 'Delhi Metro Rail Corporation (DMRC) - 390+ km across 12 lines & Airport Express',
          road: 'Eastern & Western Peripheral Expressways, Delhi-Meerut Expressway',
          transit: 'Regional Rapid Transit System (Namo Bharat RRTS) high-speed corridors'
        }),
        education: JSON.stringify([
          'All India Institute of Medical Sciences (AIIMS New Delhi)',
          'Indian Institute of Technology Delhi (IIT Delhi)',
          'Delhi University (DU - St. Stephen\'s, SRCC, Hindu College)',
          'Jawaharlal Nehru University (JNU)',
          'Jamia Millia Islamia & National Law University Delhi'
        ]),
        healthcare: JSON.stringify([
          'AIIMS New Delhi (Apex medical institute of India)',
          'Medanta - The Medicity',
          'Max Super Speciality Hospital Saket',
          'Fortis Escorts Heart Institute Okhla',
          'Sir Ganga Ram Hospital & Apollo Indraprastha'
        ]),
        economy: 'Center for national government operations, embassy diplomacy, telecommunications, FMCG distribution, IT & ITeS services, startups (Gurugram and Noida NCR corridor), and expansive wholesale retail markets.',
        specializations: 'National Capital of India, Historic Heart, Political & Diplomatic Nexus, Heritage & Culinary Capital',
        image_url: 'https://images.unsplash.com/photo-1587474260584-136574528ed5?auto=format&fit=crop&w=1200&q=80',
        latitude: 28.6139,
        longitude: 77.209
      },
      {
        name: 'Hyderabad',
        state: 'Telangana',
        country: 'India',
        description: 'The City of Pearls blends regal Nizami history with ultra-modern biotechnology and information technology infrastructure. Famous for aromatic Hyderabadi Biryani, glittering diamond trade history, and the towering HITEC City tech ecosystem.',
        population: '10.8 Million',
        area: '650 sq km',
        language: 'Telugu, Urdu, Hindi, English',
        currency: 'INR (₹)',
        attractions: JSON.stringify([
          'Charminar with four grand minarets and Laad Bazaar',
          'Golconda Fort with acoustic echoes and Light & Sound show',
          'Hussain Sagar Lake with giant monolithic Buddha statue',
          'Ramoji Film City (World\'s largest film studio complex)',
          'Salar Jung Museum (Global antique treasures)',
          'Chowmahalla Palace of the Asaf Jahi dynasty',
          'Qutb Shahi Tombs heritage park'
        ]),
        transportation: JSON.stringify({
          air: 'Rajiv Gandhi International Airport (HYD) at Shamshabad',
          rail: 'Secunderabad Junction, Hyderabad Deccan (Nampally), and Kacheguda Stations',
          metro: 'Hyderabad Metro Rail (Red, Blue, Green elevated corridors)',
          road: '158-km 8-lane Nehru Outer Ring Road (ORR) and PVNR Elevated Expressway',
          transit: 'TSRTC city bus fleet and planned Airport Express Metro line'
        }),
        education: JSON.stringify([
          'Indian Institute of Technology Hyderabad (IIT Hyderabad)',
          'International Institute of Information Technology Hyderabad (IIIT-H)',
          'BITS Pilani Hyderabad Campus',
          'Indian School of Business (ISB)',
          'University of Hyderabad & Osmania University'
        ]),
        healthcare: JSON.stringify([
          'Apollo Health City Jubilee Hills',
          'AIG Hospitals Gachibowli (Gastroenterology center)',
          'Yashoda Hospitals Somajiguda & Hitec City',
          'KIMS Hospitals (Krishna Institute of Medical Sciences)',
          'Care Hospitals Banjara Hills'
        ]),
        economy: 'Global pharmaceutical and vaccine capital produces 1 in 3 global vaccines in Genome Valley. Tech nerve center in HITEC City with Microsoft, Amazon, Google, Meta, and Apple campuses, plus aerospace and defence laboratories.',
        specializations: 'City of Pearls, Cyberabad, Vaccine & Pharma Capital of the World, Culinary World City (UNESCO)',
        image_url: 'https://images.unsplash.com/photo-1604999333679-b86d54738315?auto=format&fit=crop&w=1200&q=80',
        latitude: 17.385,
        longitude: 78.4867
      }
    ];

    for (const city of sampleCities) {
      insertCity.run(
        city.name,
        city.state,
        city.country,
        city.description,
        city.population,
        city.area,
        city.language,
        city.currency,
        city.attractions,
        city.transportation,
        city.education,
        city.healthcare,
        city.economy,
        city.specializations,
        city.image_url,
        city.latitude,
        city.longitude
      );
    }
  }

  // Check news count
  const newsCount = db.prepare('SELECT COUNT(*) as count FROM news').get().count;
  if (newsCount === 0) {
    console.log('Seeding initial city news...');
    const insertNews = db.prepare(`
      INSERT INTO news (city_id, title, summary, content, category, source, image_url, published_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const sampleNews = [
      {
        cityName: 'Chennai',
        title: 'Chennai Metro Phase 2 Tunneling Breakthrough Achieved',
        summary: 'CMRL achieves critical milestone with successful underground boring under the Adyar River corridor.',
        content: 'Chennai Metro Rail Limited (CMRL) celebrated a major infrastructure milestone this morning as the tunnel boring machine emerged at Adyar Junction. The 118.9 km Phase 2 network will connect key IT corridors with the central business district, drastically cutting urban commuter emissions and transit times.',
        category: 'Transportation',
        source: 'Chennai Urban Infrastructure Times',
        image_url: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80',
        published_at: new Date(Date.now() - 3600000 * 4).toISOString()
      },
      {
        cityName: 'Madurai',
        title: 'Madurai Smart City Heritage Walkway and Green Corridor Inaugurated',
        summary: 'Restored Chithirai streets around Meenakshi Temple opened for eco-pedestrians and electric buggies.',
        content: 'Under the National Smart Cities Mission, Madurai Municipal Corporation completed the pedestrianization and aesthetic heritage lighting of the perimeter streets surrounding Meenakshi Temple. Equipped with smart solar streetlights and emergency SOS pillars, the initiative preserves historic charm while bolstering cultural tourism.',
        category: 'Urban Heritage',
        source: 'Madurai Heritage Chronicle',
        image_url: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=800&q=80',
        published_at: new Date(Date.now() - 3600000 * 12).toISOString()
      },
      {
        cityName: 'Coimbatore',
        title: 'Coimbatore Foundry and EV Component Cluster Expands into Aerospace',
        summary: 'Over 200 precision engineering firms in Coimbatore secure international aerospace precision contracts.',
        content: 'Building on its decades-long reputation as India\'s pump and motor capital, Coimbatore\'s manufacturing cluster has officially launched the Precision Aerospace and EV Consortium. With state-of-the-art testing laboratories and green metal casting certifications, local enterprises continue to pioneer green manufacturing.',
        category: 'Economy & Tech',
        source: 'Western Ghats Industrial Digest',
        image_url: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&q=80',
        published_at: new Date(Date.now() - 3600000 * 18).toISOString()
      },
      {
        cityName: 'Bengaluru',
        title: 'Bengaluru Implements AI-Driven Adaptive Traffic Control across 120 Intersections',
        summary: 'Synchronized sensor grid reduces peak hour congestion on Outer Ring Road by 24%.',
        content: 'The Bengaluru Traffic Police and Urban Mobility Directorate have rolled out an intelligent camera and sensor-based adaptive signal system across the electronic city and tech corridors. The machine learning model recalculates green light durations dynamically depending on real-time vehicle density.',
        category: 'Smart Mobility',
        source: 'Silicon City Tech Journal',
        image_url: 'https://images.unsplash.com/photo-1508873696983-2df5293cb32f?auto=format&fit=crop&w=800&q=80',
        published_at: new Date(Date.now() - 3600000 * 26).toISOString()
      },
      {
        cityName: 'Mumbai',
        title: 'Coastal Road Green Promenade and Cycling Track Opens to Citizens',
        summary: 'Mumbai transforms reclaimed shoreline into a 7.5 km seaside green lung for citizens.',
        content: 'The newly inaugurated coastal promenade in South Mumbai features jogging tracks, open-air amphitheaters, and indigenous mangrove plantations. Integrated with rainwater harvesting filters and smart waste monitoring compactors, the public park establishes a new standard for civic coastal spaces.',
        category: 'Environment',
        source: 'Mumbai Civic Voice',
        image_url: 'https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&fit=crop&w=800&q=80',
        published_at: new Date(Date.now() - 3600000 * 32).toISOString()
      },
      {
        cityName: 'Delhi',
        title: 'Delhi Solar City Rooftop Mission Crosses 500 Megawatt Milestone',
        summary: 'Government and institutional buildings transition to 100% clean solar generation.',
        content: 'The Capital Green Power initiative announced that more than 3,000 public schools, hospitals, and administrative offices have installed automated net-metered solar arrays. The smart grid feed-in has stabilized peak summer demand and lowered regional carbon footprints significantly.',
        category: 'Clean Energy',
        source: 'Capital Urban Monitor',
        image_url: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=800&q=80',
        published_at: new Date(Date.now() - 3600000 * 40).toISOString()
      },
      {
        cityName: 'Hyderabad',
        title: 'Genome Valley Phase 3 Expansion Attracts Global Biotech R&D Labs',
        summary: 'Hyderabad strengthens global life sciences leadership with new Bio-incubator campus.',
        content: 'Hyderabad\'s Genome Valley, already responsible for over a third of global vaccine manufacturing, inaugurated its advanced bio-innovation cluster today. The center provides cloud-connected genomic sequencing facilities and sterile prototyping cleanrooms for emerging bio-health startups.',
        category: 'Healthcare & Science',
        source: 'Deccan Biotech Herald',
        image_url: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=800&q=80',
        published_at: new Date(Date.now() - 3600000 * 48).toISOString()
      }
    ];

    for (const item of sampleNews) {
      const cityRow = db.prepare('SELECT id FROM cities WHERE name = ?').get(item.cityName);
      const cityId = cityRow ? cityRow.id : null;
      insertNews.run(
        cityId,
        item.title,
        item.summary,
        item.content,
        item.category,
        item.source,
        item.image_url,
        item.published_at
      );
    }
  }

  // Seed sample favorites for citizen user
  const favCount = db.prepare('SELECT COUNT(*) as count FROM favorites').get().count;
  if (favCount === 0) {
    const citizen = db.prepare('SELECT id FROM users WHERE email = ?').get('citizen@smartcity.gov');
    const chennai = db.prepare('SELECT id FROM cities WHERE name = ?').get('Chennai');
    const bengaluru = db.prepare('SELECT id FROM cities WHERE name = ?').get('Bengaluru');

    if (citizen && chennai && bengaluru) {
      const insertFav = db.prepare('INSERT OR IGNORE INTO favorites (user_id, city_id) VALUES (?, ?)');
      insertFav.run(citizen.id, chennai.id);
      insertFav.run(citizen.id, bengaluru.id);
    }
  }
}

// Initialize on load
initializeDatabase();

module.exports = db;
